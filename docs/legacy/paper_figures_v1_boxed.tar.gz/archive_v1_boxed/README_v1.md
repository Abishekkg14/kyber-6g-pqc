# Paper figures (architecture diagrams)

Ten architecture diagrams for the Kyber-6G paper, as editable draw.io sources and as publication files for an Elsevier
journal: vector PDF and EPS at the exact column width, plus 600 dpi PNG previews.

```
paper_figures/
├── raw_drawio/      editable .drawio sources (open in draw.io / diagrams.net)
├── exported_pdf/    vector PDF, tight box, exact width: 90 mm or 190 mm      <- submit these
├── exported_eps/    vector EPS made from the same PDFs                        <- or these, if the system asks for EPS
├── exported_png/    600 dpi previews
├── assets/icons/    52 line icons (Tabler Icons, MIT) + manifest.json; ICON_ATTRIBUTION.md
├── checks/          build_report.md (measured values), gray/ (greyscale proofs)
└── scripts/         setup_tools.sh, fetch_icons.py, figlib.py, figures.py, build.py
```

## The figures

| No. | File stem | What it shows | Column | Size (mm) |
|---|---|---|---|---|
| 1 | `fig01_system_architecture` | UAV node, untrusted network, ground station; the six streams and the secure link | double | 190.00 × 86.91 |
| 2 | `fig02_threat_model` | Trusted endpoints, network adversary, threat-to-countermeasure map | single | 90.00 × 96.30 |
| 3 | `fig03_handshake` | Hybrid post-quantum handshake, message by message | double | 190.00 × 94.37 |
| 4 | `fig04_key_schedule` | From the two shared secrets to per-stream epoch keys | single | 90.00 × 94.19 |
| 5 | `fig05_session_lifecycle` | (a) link state machine, (b) key-refresh schedule | double | 190.00 × 69.32 |
| 6 | `fig06_record_layer` | (a) wire format, (b) AES-256-GCM sealing, (c) receiver checks | single | 90.00 × 82.28 |
| 7 | `fig07_video_pipeline` | Live video from capture to decoded frames | double | 190.00 × 68.27 |
| 8 | `fig08_perception_hitl` | Detector, finder, overlay and the operator loop | double | 190.00 × 66.68 |
| 9 | `fig09_recording_at_rest` | Recording key wrapping, file layout, decryption on the GCS | single | 90.00 × 88.90 |
| 10 | `fig10_evaluation_workflow` | Prototype measurements calibrating the ns-3 simulation | double | 190.00 × 61.24 |

Every stem exists as `raw_drawio/<stem>.drawio`, `exported_pdf/<stem>.pdf`, `exported_eps/<stem>.eps` and
`exported_png/<stem>.png`.

In LaTeX the files are already at their final size, so include them unscaled:

```latex
\begin{figure}[t]   \centering \includegraphics{paper_figures/exported_pdf/fig04_key_schedule}        \caption{...} \end{figure}
\begin{figure*}[t]  \centering \includegraphics{paper_figures/exported_pdf/fig01_system_architecture} \caption{...} \end{figure*}
```

## Suggested captions

1. End-to-end architecture of the prototype. Six logical streams between the UAV node and the ground control station
   share one UDP flow over Wi-Fi/IP; all of them pass through the same secure link (hybrid post-quantum handshake,
   HKDF key schedule, AEAD records).
2. Threat model. The endpoints are trusted; the network adversary controls the channel and may store traffic for
   later cryptanalysis. Each threat is paired with the mechanism that counters it.
3. Full handshake (1.5 round trips). ML-KEM-1024 and X25519 supply the shared secrets, ML-DSA-87 signatures made
   with pinned long-term keys authenticate both sides, and the Finished MACs confirm the derived keys.
4. Key schedule. The two shared secrets are concatenated and extracted with the transcript hash as salt; all
   further keys are HKDF-Expand outputs under distinct labels. Every stream and direction has its own one-way chain
   of epoch keys.
5. Session lifecycle. (a) Link state machine on the UAV. (b) Key refresh in an established session with the default
   intervals: epoch rotation, 1-RTT Cached RapidRekey and PQ ratchet.
6. AEAD record layer. (a) Wire format of one record. (b) Sealing with AES-256-GCM; the nonce is derived from the
   sequence number and is not transmitted. (c) Receiver checks in the order in which they are applied.
7. Live-video path. Each encoded access unit is split into chunks, each chunk is sealed as its own AEAD record and
   sent as one UDP datagram; the ground station verifies, reassembles and decodes.
8. Perception and operator loop on the ground station. A real-time detector and a slower open-vocabulary finder
   analyse the decoded frames; their boxes are placed by the capture time of the frame. Operator input returns as
   teaching examples and as commands on the control stream.
9. Recordings at rest. The content key is generated on the UAV and wrapped to the ML-KEM-1024 key of the ground
   station; the UAV keeps no key that can decrypt a finished recording.
10. Evaluation workflow. Timings measured on the prototype calibrate the ns-3 model. The simulator models
    cryptography by message size and delay and does not execute it; the 5G NR radio exists only in the simulation,
    the prototype runs over Wi-Fi.

Wording that the figures and captions keep to: the rekey is **1-RTT** Cached RapidRekey (not 0-RTT); ML-KEM and
ML-DSA establish and authenticate the session, **AES-256-GCM** encrypts the data (the video is not "post-quantum
encrypted"); the prototype radio is **Wi-Fi**, not 5G/6G.

## Where each figure's content comes from

Figures 1–9 state what the implementation does; the labels were taken from the code, not from older documents.

| Figure | Source in the repository |
|---|---|
| 1 | `kyber6g/uav/main.py`, `kyber6g/ground/main.py`, `kyber6g/config.py`, stream ids in `kyber6g/crypto/keyschedule.py` |
| 2 | `docs/SECURITY_ARCHITECTURE.md` §1 and the mechanisms in `kyber6g/crypto/` |
| 3 | `kyber6g/crypto/handshake.py` (`ClientHandshake`, `ServerHandshake`) |
| 4 | `kyber6g/crypto/keyschedule.py` (`SessionSecrets`, `EpochChain`) |
| 5 | `kyber6g/transport/link.py` (`UavLink._manage`), defaults in `kyber6g/config.py` (`LinkConfig`) |
| 6 | `kyber6g/crypto/record.py`, `kyber6g/crypto/replay.py`; the inside of the GCM box is the standard construction |
| 7 | `kyber6g/camera/camera.py`, `kyber6g/ground/video_sink.py` |
| 8 | `kyber6g/ground/detector.py`, `kyber6g/ground/finder.py`, `kyber6g/ground/store.py` |
| 9 | `kyber6g/recording/recorder.py`, `kyber6g/tools/decrypt_recording.py` |
| 10 | `README.md` (top level), `docs/simulation-methodology.md`, `ns-3-dev/contrib/pqc-security/` |

Figure 10 is drawn from the repository's documentation of the simulation; the simulation itself was not re-run for
this figure. No figure contains a measured result.

## Rebuild

```bash
sudo bash paper_figures/scripts/setup_tools.sh     # once: draw.io Desktop, Ghostscript, pdfcrop, fonts, pypdf
python3 paper_figures/scripts/fetch_icons.py       # once: downloads the icons into assets/icons
python3 paper_figures/scripts/build.py             # all figures;  build.py fig03 fig07  for a subset
```

`figures.py` holds one function per figure. Change a label or a coordinate there and run `build.py`; it writes the
`.drawio` file, exports it with the draw.io command line (headless, under xvfb), crops it with `pdfcrop`, scales the
page to exactly 90 mm or 190 mm, and derives EPS and PNG from that PDF. A figure edited by hand in draw.io can be
exported from there (File > Export as > PDF, "Crop"), but `build.py` regenerates `raw_drawio/` from `figures.py`
and would overwrite the manual edit.

## Standards applied

- **Width:** exactly 90 mm (single column) or 190 mm (double column), no margins.
- **Type:** Arial only, embedded. Headers 9 pt, block labels 8 pt, notes 7 pt, subscripts and indices 6.5 pt;
  nothing smaller. Variables are italic (*ss*, *TH*, *IKM*, *CEK*, *N*), acronyms and algorithm names upright.
  Concatenation is written `||` because Arial has no ‖ glyph (it would pull in a second font).
- **Colour:** card fills `#F8FAFC` / `#F1F5F9`, card borders `#94A3B8` at 1 pt, text and lines `#1E293B` /
  `#0F172A` at 1.2 pt, no pure black. Two accents: navy `#1E3A8A` for the data path, crimson `#991B1B` for keys and
  cryptographic operations.
- **Greyscale:** the accents are both dark in grey, so meaning is also carried by line style: solid = data,
  dashed = key material, dotted = operator commands / control stream.
- **Connectors:** right-angle routing only, arc hops where two lines cross, triangular heads 4 pt long and 3 pt wide.
  XOR is the circle with a cross, concatenation the circle with `||`, splitting into chunks the circle with a bar.
- **Icons:** one family (Tabler Icons outline, MIT), 1.5 pt stroke at every size, ink or accent colour, no fills.
  `fetch_icons.py` rejects any icon that is not stroke-only.

## What was measured on the output (see `checks/build_report.md`)

| Check | Result |
|---|---|
| Page width | 90.00 mm and 190.00 mm on all ten PDFs |
| Text sizes in the PDFs (poppler word boxes) | 6.5, 7.0, 8.0 and 9.0 pt; nothing below 6.5 pt |
| Fonts | ArialMT, Arial-BoldMT, Arial-ItalicMT only, embedded subsets |
| Raster images inside the PDFs | none (icons stay vector) |
| Connectors drawn by draw.io as designed | 151 of 151 (route of every connector compared with the exported SVG) |
| Connector over text, text over text, label wider than its block | none (checked from text measured with the real font) |
| Line width | 1.20 pt |
| Arrowhead | 3.97 pt long, 3.00 pt wide |
| Contrast of text and connectors against the fills | 7.9 : 1 or more (crimson on a card is the lowest); the grey card borders are 2.5 : 1 |
| EPS | all ten render in Ghostscript, bounding boxes 256 pt and 539 pt wide |
| PNG | 2126 px (90 mm) and 4489 px (190 mm) wide = 600 dpi |

Not checked: how the files pass a specific journal's artwork checker, and printing on paper.

## Notes

- Arrowheads are small triangle shapes, not draw.io's line markers. The markers are stroked with the line width and
  cannot be 4 pt × 3 pt at a 1.2 pt line (measured: 4.12 × 2.76 pt or 4.58 × 3.06 pt). Each head belongs to the
  block it points at, so it moves with that block in the editor. `HEAD_STYLE = "marker"` in `figlib.py` switches
  back to native markers.
- draw.io's PDF export is not at a fixed scale (about 0.716 pt per unit here), which is why `build.py` scales the
  cropped page to the exact width instead of trusting the export.
- Subscripts are 6.5 pt next to 7 pt text, so they look larger than usual; that is the price of the 6.5 pt minimum.
