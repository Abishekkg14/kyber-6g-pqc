#!/usr/bin/env python3
"""The figures of the paper, described with figlib. Every label states something the implementation does
(kyber6g/crypto, kyber6g/transport, kyber6g/recording, kyber6g/ground) or, for the evaluation workflow, something the
repository documents. Coordinates are draw.io units; see figlib for the unit and style conventions."""
from figlib import (BORDER, CARD, CARD2, CRIMSON, FS_B, FS_H, FS_MIN, FS_N, INK, INK2, NAVY, W1, W2, WHITE, Fig, small, var)

E = 0.67            # half of a 1 pt card border: cards start here so that their outer edge is exactly at 0 / W


def fig01_system_architecture():
    W, H = W2, 334.0
    f = Fig("fig01_system_architecture", W, H, "End-to-end architecture of the secure multimodal UAV-to-ground link")
    ry = lambda r: 34 + 40 * r                                   # top of row r (rows are aligned across the three zones)
    bh, cb = 30, 312.0                                           # block height, bottom of the cards
    # ---- UAV node
    f.card(E, E, 264, cb - E, "UAV node (Raspberry Pi 4B)", icon="uav")
    sx, sw, lx, lw = 8.67, 128, 154.67, 102
    src = [("Camera", "OV5647, 720p, 30 fps", "camera", "plain"), ("H.264 encoder", "hardware, 3 Mbit/s", "video", "plain"),
           ("Recorder", "encrypted, SD card", "sd_card", "crypto"), ("Still capture", "JPEG, up to 5 MP", "image", "plain"),
           ("GNSS receiver", "position, 1 Hz", "gnss", "plain"), ("System status", "health, storage", "telemetry", "plain"),
           ("Commands", "camera, recorder, link", "command", "plain")]
    for r, (t, s, ic, kind) in enumerate(src):
        f.block(sx, ry(r), sw, bh, t, kind, sub=s, icon=ic)
    link_label = ("<b>Secure link</b><br>" + small("hybrid PQ handshake<br>HKDF key schedule<br>per-stream keys<br>AEAD records<br>"
                                                   "replay window<br>epochs, rekey, ratchet"))
    f.block(lx, ry(0), lw, ry(6) + bh - ry(0), link_label, "crypto", bold=False, fill=CARD2)
    f.icon("shield", lx + lw / 2 - 9, ry(0) + 64, 18, CRIMSON)
    mid = sx + sw / 2
    f.edge([(mid, ry(0) + bh), (mid, ry(1))], "data")
    f.edge([(mid, ry(1) + bh), (mid, ry(2))], "data")
    for r in (1, 2, 3, 4, 5):
        f.edge([(sx + sw, ry(r) + 15), (lx, ry(r) + 15)], "data")
    f.edge([(lx, ry(6) + 15), (sx + sw, ry(6) + 15)], "cmd")
    # ---- ground control station
    gx = 443.44
    f.card(gx, E, W - E - gx, cb - E, "Ground control station", icon="ground_station")
    glx, cx, cw = gx + 8, 571.44, 128
    f.block(glx, ry(0), lw, ry(6) + bh - ry(0), link_label, "crypto", bold=False, fill=CARD2)
    f.icon("shield", glx + lw / 2 - 9, ry(0) + 64, 18, CRIMSON)
    dst = [("Detector, finder", "YOLOE, OWLv2", "detector", "plain"), ("Video sink", "reorder, decode", "movie", "plain"),
           ("Recordings", "GCS-only decryption", "lock_open", "crypto"), ("Image store", "SHA-256 verified", "image", "plain"),
           ("Telemetry store", "SQLite", "database", "plain")]
    for r, (t, s, ic, kind) in enumerate(dst):
        f.block(cx, ry(r), cw, bh, t, kind, sub=s, icon=ic)
    f.block(cx, ry(5), cw, ry(6) + bh - ry(5), "Dashboard", "plain", sub="operator in the loop<br>live view, commands", icon="dashboard")
    for r in (1, 2, 3, 4, 5):
        f.edge([(glx + lw, ry(r) + 15), (cx, ry(r) + 15)], "data")
    f.edge([(cx, ry(6) + 15), (glx + lw, ry(6) + 15)], "cmd")
    gm = cx + cw / 2
    f.edge([(gm, ry(1)), (gm, ry(0) + bh)], "data")
    f.edge([(cx + cw, ry(0) + 15), (cx + cw + 9, ry(0) + 15), (cx + cw + 9, ry(5) + 15), (cx + cw, ry(5) + 15)], "data")
    # ---- untrusted channel
    x0, x1 = lx + lw, glx
    cxm = (264.67 + gx) / 2
    f.icon("adversary", cxm - 66, 2, 18)
    f.text(cxm - 44, 3, 112, 16, "Untrusted network", fs=FS_H, align="left", bold=True, color=INK2)
    f.text(264.67, 20, gx - 264.67, 12, "read, drop, replay, modify, inject")
    rows = [(0, "handshake, cached rekey", "key", "both"), (1, "video", "data", "end"), (2, "recording file", "data", "end"),
            (3, "image", "data", "end"), (4, "telemetry", "data", "end"), (5, "status", "data", "end"), (6, "control", "cmd", "start")]
    for r, label, kind, arrow in rows:
        y = ry(r) + 15
        pts = [(x0, y), (x1, y)] if arrow != "start" else [(x1, y), (x0, y)]
        f.edge(pts, kind, "both" if arrow == "both" else "end")
        f.text(264.67, y - 14, gx - 264.67, 12, label)
    f.text(264.67, ry(6) + 19, gx - 264.67, 12, "Wi-Fi / IP, one UDP flow, ≤ 1472 B")
    f.legend(190, 324, [("data", "application data in AEAD records"), ("cmd", "control"), ("key", "key establishment")])
    return f


def fig02_threat_model():
    W, H = W1, 372.0
    f = Fig("fig02_threat_model", W, H, "Threat model: trusted endpoints, network adversary and the countermeasure for each threat")
    cw, ch = 104, 100
    gx = W - E - cw
    f.card(E, E, cw, ch, "UAV", icon="uav")
    f.text(E, 30, cw, 62, "trusted endpoint<br>ML-DSA-87 identity<br>pinned GCS keys", valign="top")
    f.card(gx, E, cw, ch, "GCS", icon="ground_station")
    f.text(gx, 30, cw, 62, "trusted endpoint<br>ML-DSA-87 identity<br>pinned UAV key<br>recording key pair", valign="top")
    mx, mw = E + cw, gx - (E + cw)
    f.icon("adversary", mx + mw / 2 - 12, 1, 24)
    f.text(mx, 27, mw, 14, "Network adversary", fs=FS_B, bold=True, color=INK2)
    f.text(mx, 41, mw, 36, "read, drop, delay, reorder,<br>replay, modify, inject,<br>store now, decrypt later")
    f.edge([(mx, 88), (gx, 88)], "ctrl", "both", attach=False)
    # threat -> countermeasure
    y0, tw, ax = 116, 124, 18
    f.text(E, y0 - 4, tw, 14, "Threat", fs=FS_B, bold=True, color=INK2)
    f.icon("shield_check", E + tw + ax + 30, y0 - 7, 18, CRIMSON)
    f.text(E + tw + ax + 52, y0 - 4, 140, 14, "Countermeasure", fs=FS_B, bold=True, color=INK2, align="left")
    rows = [("Eavesdropping", "store now, decrypt later", "Hybrid ML-KEM-1024 + X25519 handshake,<br>AES-256-GCM on every record"),
            ("Impersonation", "man in the middle", "Pinned ML-DSA-87 keys, signed transcript,<br>Finished MACs confirm the keys"),
            ("Replay", "duplicates, reordering", "64-bit sequence number in every record,<br>2048-entry sliding window per stream"),
            ("Tampering", "modification, injection", "AEAD tag covers header, metadata<br>and payload; failures are counted"),
            ("Downgrade", "weaker algorithm suite", "Suite ID is signed and bound into<br>the transcript hash and all keys"),
            ("Key compromise", "past and future traffic", "Ephemeral keys, 30 s one-way key epochs,<br>PQ ratchet heals a compromised session"),
            ("Seized UAV", "SD card with recordings", "Content key wrapped to the ML-KEM-1024<br>key of the GCS; the UAV cannot decrypt")]
    for i, (t, s, m) in enumerate(rows):
        y = y0 + 14 + 34 * i
        f.block(E, y, tw, 30, t, "ink", sub=s)
        f.block(E + tw + ax, y, W - E - (E + tw + ax), 30, small(m), "plain", bold=False)
        f.edge([(E + tw, y + 15), (E + tw + ax, y + 15)], "ctrl")
    return f


def fig03_handshake():
    W, H = W2, 356.67
    f = Fig("fig03_handshake", W, H, "Hybrid post-quantum handshake (1.5 round trips) between UAV and GCS")
    cw = 240
    lx, rx = E, W - E - cw
    f.card(lx, E, cw, H - 2 * E, "UAV (client)", icon="uav")
    f.card(rx, E, cw, H - 2 * E, "GCS (server)", icon="ground_station")
    bx, bw = 8, cw - 16
    x0, x1 = lx + cw, rx
    mw = x1 - x0
    sk, pk, ss = (lambda s: var("sk", s)), (lambda s: var("pk", s)), (lambda s: var("ss", s))
    NC, NS, TH = var("N", "C"), var("N", "S"), "<i>TH</i>"
    sigU, sigG = var("sig", "UAV"), var("sig", "GCS")
    finS, finC = var("Fin", "S"), var("Fin", "C")
    f.text(x0, 4, mw, 16, "Full handshake, 1.5 round trips", fs=FS_H, bold=True, color=INK2)
    # 1
    f.block(lx + bx, 28, bw, 60, "1&nbsp; Ephemeral keys, signed hello", "crypto", align="left",
            sub=f"X25519 ({sk('C')}, {pk('C')}), ML-KEM-1024 (<i>dk</i>, <i>ek</i>)<br>nonce {NC}, timestamp, mobility cell<br>"
                f"{sigU} = ML-DSA-87.Sign(ClientHello)")
    f.edge([(x0, 58), (x1, 58)], "key", attach=False)
    f.text(x0, 42, mw, 14, "ClientHello", fs=FS_B, bold=True, color=INK2)
    f.text(x0, 62, mw, 26, f"suite, UAV ID, {NC}, cell, timestamp,<br>{pk('C')}, <i>ek</i>, {sigU}")
    # 2
    f.block(rx + bx, 70, bw, 99, "2&nbsp; Authenticate, encapsulate, derive", "crypto", align="left",
            sub=f"verify {sigU} (pinned key), freshness ±120 s<br>(<i>ct</i>, {ss('KEM')}) = ML-KEM-1024.Encaps(<i>ek</i>)<br>"
                f"{ss('X')} = X25519({sk('S')}, {pk('C')})<br>{TH} = SHA-256(ClientHello || {sigU} || ServerHello)<br>"
                f"{sigG} = ML-DSA-87.Sign({TH})<br>{finS} = HMAC({var('K', 'S')}, SHA-256({TH} || {sigG}))")
    f.edge([(x1, 180), (x0, 180)], "key", attach=False)
    f.text(x0, 164, mw, 14, "ServerHello", fs=FS_B, bold=True, color=INK2)
    f.text(x0, 184, mw, 26, f"suite, session ID, {NS}, GCS ID,<br>{pk('S')}, <i>ct</i>, {sigG}, {finS}")
    # 3
    f.block(lx + bx, 190, bw, 60, "3&nbsp; Authenticate, decapsulate, confirm", "crypto", align="left",
            sub=f"verify {sigG} (pinned key), same suite<br>{ss('KEM')} = Decaps(<i>dk</i>, <i>ct</i>), {ss('X')} = X25519({sk('C')}, {pk('S')})<br>"
                f"derive keys, check {finS}")
    f.edge([(x0, 264), (x1, 264)], "key", attach=False)
    f.text(x0, 248, mw, 14, "ClientFinished", fs=FS_B, bold=True, color=INK2)
    f.text(x0, 268, mw, 13, f"session ID, {finC}")
    # 4
    f.block(rx + bx, 256, bw, 36, "4&nbsp; Confirm", "crypto", align="left", sub=f"check {finC}, cache the resumption secret")
    f.block(x0 + 12, 290, mw - 24, 30, f"<i>IKM</i> = {ss('KEM')} || {ss('X')}", "plain", bold=False,
            sub=f"<i>PRK</i> = HKDF-Extract(salt = {TH}, <i>IKM</i>)")
    f.edge([(x0, 340), (x1, 340)], "data", "both", attach=False)
    f.text(x0, 324, mw, 14, "application records under AEAD", fs=FS_N)
    return f


def fig04_key_schedule():
    W, H = W1, 356.0
    f = Fig("fig04_key_schedule", W, H, "Key schedule: from the hybrid shared secrets to per-stream epoch keys")
    cw = 104
    c1, c2, c3 = E + 4, (W - cw) / 2, W - E - 4 - cw                   # three columns
    m1, m2, m3 = c1 + cw / 2, c2 + cw / 2, c3 + cw / 2
    f.card(E, E, W - 2 * E, H - 2 * E)
    # inputs
    f.block(c1, 8, cw, 30, var("ss", "KEM"), "ink", sub="ML-KEM-1024", bold=False)
    f.block(c2, 8, cw, 30, var("ss", "X"), "ink", sub="X25519", bold=False)
    f.block(c3, 8, cw, 30, "<i>TH</i>", "ink", sub="transcript hash", bold=False)
    ox = (m1 + m2) / 2
    f.op("concat", ox, 54)
    f.edge([(m1, 38), (m1, 54), (ox - 7, 54)], "ctrl")
    f.edge([(m2, 38), (m2, 54), (ox + 7, 54)], "ctrl")
    ex = ox - cw / 2
    f.block(ex, 76, cw, 24, "HKDF-Extract", "crypto")
    f.edge([(ox, 61), (ox, 76)], "ctrl")
    f.text(ox + 5, 62, 30, 12, "<i>IKM</i>", align="left")
    f.edge([(m3, 38), (m3, 88), (ex + cw, 88)], "ctrl")
    f.text(ex + cw + 8, 75, 40, 12, "salt", align="left")
    f.block(ex, 118, cw, 24, "HKDF-Expand", "crypto")
    f.edge([(ox, 100), (ox, 118)], "ctrl")
    f.text(ox + 5, 103, 30, 12, "<i>PRK</i>", align="left")
    f.text(ex + cw + 8, 116, W - E - 6 - (ex + cw + 8), 28, "info = purpose label,<br>suite ID, session ID", align="left")
    # first-level secrets
    y1 = 166
    f.block(c1, y1, cw, 30, "Finished keys", "ink", sub="server, client", bold=False)
    f.block(c2, y1, cw, 30, "Master secret", "ink", sub="per session", bold=False)
    f.block(c3, y1, cw, 30, "Resumption", "ink", sub="for cached rekey", bold=False)
    f.edge([(ox - 14, 142), (ox - 14, 154), (m1, 154), (m1, y1)], "ctrl")
    f.edge([(ox + 14, 142), (ox + 14, 154), (m2, 154), (m2, y1)], "ctrl")
    f.edge([(c2 + cw, y1 + 15), (c3, y1 + 15)], "ctrl")
    y2 = 216
    f.block(c3, y2, cw, 24, "Rekey MAC key", "ink")
    f.edge([(m3, y1 + 30), (m3, y2)], "ctrl")
    f.block(c1, y2, c2 + cw - c1, 30, "Chain keys", "ink", sub="one per stream and direction (6 × 2)", bold=False)
    f.edge([(m2, y1 + 30), (m2, y2)], "ctrl")
    # epoch chain
    y3, y4 = 274, 314
    for i, (c, m) in enumerate(((c1, m1), (c2, m2), (c3, m3))):
        f.block(c, y3, cw, 24, var("chain", str(i)), "ink")
        f.block(c, y4, cw, 24, var("key", str(i)), "data", bold=False)
        f.edge([(m, y3 + 24), (m, y4)], "ctrl")
    f.edge([(m1, y2 + 30), (m1, y3)], "ctrl")
    f.edge([(c1 + cw, y3 + 12), (c2, y3 + 12)], "ctrl")
    f.edge([(c2 + cw, y3 + 12), (c3, y3 + 12)], "ctrl")
    f.text(c1 + cw, y2 + 34, c3 - (c1 + cw) + cw, 12, "next epoch every 30 s or 2<sup style=\"font-size:8.67px;line-height:0\">20</sup> records", align="left")
    f.text(E, y4 + 26, W - 2 * E, 12, "AEAD key of each epoch; the previous chain value is erased")
    return f


def fig05_session_lifecycle():
    W, H = W2, 262.0
    f = Fig("fig05_session_lifecycle", W, H, "Session lifecycle: link state machine and the key-refresh schedule of an established session")
    # ---- (a) state machine, as implemented in UavLink._manage
    aw = 338
    f.card(E, E, aw, H - 2 * E, "(a) Link state machine (UAV side)")
    sw, sh, xs, y1, y2 = 86, 26, (10, 126, 242), 56, 122
    f.block(xs[0], y1, sw, sh, "DOWN", "ink")
    f.block(xs[1], y1, sw, sh, "HANDSHAKING", "ink")
    f.block(xs[2], y1, sw, sh, "CONFIRMING", "ink")
    f.block(xs[1], y2, sw, sh, "RECOVERING", "ink")
    f.block(xs[2], y2, sw, sh, "UP", "data", bold=True)
    m = [x + sw / 2 for x in xs]
    f.edge([(xs[0] + sw, y1 + 13), (xs[1], y1 + 13)], "ctrl");                         f.tag(1, (xs[0] + sw + xs[1]) / 2, y1 + 2)
    f.edge([(xs[1] + sw, y1 + 13), (xs[2], y1 + 13)], "ctrl");                         f.tag(2, (xs[1] + sw + xs[2]) / 2, y1 + 2)
    f.edge([(m[2], y1 + sh), (m[2], y2)], "ctrl");                                     f.tag(3, m[2] + 12, (y1 + sh + y2) / 2)
    f.edge([(xs[2], y2 + 13), (xs[1] + sw, y2 + 13)], "ctrl");                         f.tag(4, (xs[1] + sw + xs[2]) / 2, y2 + 2)
    f.edge([(m[1], y2), (m[1], y1 + sh)], "ctrl");                                     f.tag(5, m[1] + 12, (y1 + sh + y2) / 2)
    f.edge([(m[1] - 24, y1 + sh), (m[1] - 24, y1 + sh + 14), (m[0], y1 + sh + 14), (m[0], y1 + sh)], "ctrl")
    f.tag(6, (m[0] + m[1] - 24) / 2, y1 + sh + 24)
    f.edge([(m[2], y1), (m[2], y1 - 16), (m[0], y1 - 16), (m[0], y1)], "ctrl");        f.tag(7, m[1], y1 - 26)
    notes = ["start or retry (back-off 0.5 s to 8 s)", "cached rekey or full handshake succeeded, ClientFinished sent",
             "first authenticated record from the GCS", "no authenticated record for 5 s, or the mobility cell changed",
             "retry: cached rekey if the cell is unchanged, else full handshake", "handshake failed or timed out",
             "no confirmation within 5 s"]
    for i, n in enumerate(notes):
        y = 158 + 14 * i
        f.tag(i + 1, 16, y + 6.5)
        f.text(28, y, aw - 34, 13, n, align="left")
    # ---- (b) key refresh schedule (defaults of LinkConfig)
    bx = 350.0
    f.card(bx, E, W - E - bx, H - 2 * E, "(b) Key refresh in an established session (default intervals)")
    t0, t1 = bx + 100, W - 18
    X = lambda t: t0 + (t1 - t0) * t / 600
    rows = [("Full handshake", 46, [0], "key"), ("Epoch rotation", 68, range(30, 601, 30), "ctrl"),
            ("Cached rekey", 90, range(120, 601, 120), "key"), ("PQ ratchet", 112, [600], "key")]
    for name, y, times, kind in rows:
        f.text(bx + 8, y - 12, 88, 13, name, fs=FS_B, align="left")
        f.edge([(t0, y), (t1, y)], "rule", attach=False)
        for t in times:
            tall = 7 if kind == "ctrl" else 10
            f.edge([(X(t), y), (X(t), y - tall)], kind, "none", dashed=False, width=1.6 if kind == "ctrl" else 2.0, attach=False, jump=False)
    for t in range(0, 601, 120):
        f.text(X(t) - 20, 116, 40, 12, f"{t} s" if t == 600 else str(t))
    items = [("Full handshake", "at start, after a cell change, cache miss or expiry",
              "ML-KEM-1024 + X25519 key exchange, ML-DSA-87 signatures, 1.5 round trips"),
             ("Epoch rotation", "every 30 s or 2<sup style=\"font-size:8.67px;line-height:0\">20</sup> records, per stream",
              "one-way HKDF chain, no messages, the old chain value is erased"),
             ("1-RTT Cached RapidRekey", "every 120 s and on link recovery",
              "from the resumption secret, HMAC-authenticated; same cell, cache ≤ 300 s"),
             ("PQ ratchet", "every 600 s", "fresh ML-KEM-1024 + X25519 secrets mixed into the master secret")]
    for i, (name, when, how) in enumerate(items):
        y = 136 + 29 * i
        f.text(bx + 8, y, W - E - bx - 16, 27, f"<b>{name}</b>&nbsp; {small(when)}<br>{small(how)}", fs=FS_B, align="left", valign="top")
    return f


def fig06_record_layer():
    W, H = W1, 318.0
    f = Fig("fig06_record_layer", W, H, "AEAD record layer: wire format, sealing and the receiver checks")
    hdr = lambda y, t: f.text(E, y, W - 2 * E, 14, t, fs=FS_B, bold=True, align="left", color=INK2)
    # ---- (a) wire format (crypto/record.py)
    hdr(0, "(a) Record on the wire (field sizes in bytes)")
    fields = [("ver", "1", 22), ("type", "1", 24), ("stream", "1", 36), ("ext len", "1", 38), ("session ID", "8", 54), ("epoch", "4", 34),
              ("seq", "8", 30), ("ext", "n", 26), ("ciphertext", "payload", 52), ("tag", "16", W - 2 * E - 316)]
    x = E
    for i, (name, size, w) in enumerate(fields):
        f.block(x, 18, w, 30, name, "crypto" if i >= 8 else "plain", sub=size, fs=FS_N, sub_fs=FS_MIN, bold=False, rounded=False,
                fill=CARD2 if i >= 8 else WHITE)
        x += w
    xa = E + sum(w for *_, w in fields[:8])
    f.edge([(E + 1, 53), (xa - 2, 53)], "data", "none", attach=False)
    f.text(E, 55, xa - E, 12, "header and ext: authenticated as AAD, sent in clear")
    f.edge([(xa + 2, 53), (W - E - 1, 53)], "key", "none", dashed=False, attach=False)
    f.text(xa, 55, W - E - xa, 12, "AEAD output")
    # ---- (b) seal
    hdr(76, "(b) Seal: one record per chunk")
    ix, iw = 8, 84
    rows = [("seq, 64 bit", "plain", 112), ("epoch key", "crypto", 142), ("header, ext", "plain", 172), ("payload", "plain", 202)]
    for label, kind, y in rows:
        f.block(ix, y, iw, 22, label, kind)
    c = [y + 11 for *_, y in rows]
    f.op("concat", 112, c[0])
    f.text(100, c[0] - 29, 24, 12, '0<sup style="font-size:8.67px;line-height:0">32</sup>')
    f.edge([(112, c[0] - 16), (112, c[0] - 7)], "ctrl")
    f.edge([(ix + iw, c[0]), (105, c[0])], "ctrl")
    gx, gy, gw = 150, 88, 126
    f.card(gx, gy, gw, 144, "AES-256-GCM", fill=CARD2, stroke=CRIMSON)
    f.block(gx + 8, rows[0][2], 62, 22, "AES-CTR", "crypto")
    f.block(gx + 8, rows[2][2], 62, 22, "GHASH", "crypto")
    xo = 246
    f.op("xor", xo, c[0])
    f.edge([(119, c[0]), (gx + 8, c[0])], "ctrl")
    f.text(121, c[0] + 3, 28, 12, "nonce", align="left")
    f.edge([(gx + 70, c[0]), (xo - 7, c[0])], "ctrl")
    f.edge([(ix + iw, c[1]), (gx + 24, c[1]), (gx + 24, rows[0][2] + 22)], "key")
    f.edge([(ix + iw, c[2]), (gx + 8, c[2])], "data")
    f.edge([(ix + iw, c[3]), (xo, c[3]), (xo, c[0] + 7)], "data")
    ox, ow = 284, W - E - 284
    f.block(ox, rows[0][2], ow, 22, "ciphertext", "plain", fs=FS_N)
    f.block(ox, rows[2][2], ow, 22, "tag, 16 B", "plain", fs=FS_N)
    f.edge([(xo + 7, c[0]), (ox, c[0])], "data")
    f.edge([(ox + 22, rows[0][2] + 22), (ox + 22, 158), (gx + 56, 158), (gx + 56, rows[2][2])], "data")
    f.edge([(gx + 70, c[2]), (ox, c[2])], "data")
    # ---- (c) open
    hdr(240, "(c) Open: receiver checks, in this order")
    bw = 74
    gap = (W - 2 * E - 4 * bw) / 3
    checks = [("Session ID", "known session", "wrong-session"), ("Sequence no.", "window of 2048", "duplicate, stale"),
              ("Epoch key", "up to 8 ahead", "stale-epoch"), ("AEAD tag", "then commit", "auth-fail")]
    for i, (t, s, rej) in enumerate(checks):
        bx = E + i * (bw + gap)
        f.block(bx, 258, bw, 30, t, "ink", sub=s, bold=False)
        f.text(bx, 290, bw, 12, rej, color=CRIMSON, italic=True)
        if i:
            f.edge([(bx - gap, 273), (bx, 273)], "ctrl")
    f.text(E, 303, W - 2 * E, 12, "a failed check drops the record and increments the named counter")
    return f


def fig07_video_pipeline():
    W, H = W2, 258.0
    f = Fig("fig07_video_pipeline", W, H, "Secure live-video pipeline from capture on the UAV to decoded frames on the GCS")
    y, bh = 34, 34
    c = y + bh / 2
    f.card(E, E, W - 2 * E, 112, "UAV: capture, encode, protect", icon="uav")
    f.block(10, y, 118, bh, "Camera", "plain", sub="1280 × 720, 30 fps", icon="camera")
    f.block(150, y, 140, bh, "H.264 encoder", "plain", sub="IDR every 30 frames", icon="video")
    f.op("slice", 337, c, color=NAVY)
    f.text(297, c + 9, 80, 12, "chunks ≤ 1100 B")
    f.block(384, y, 156, bh, "AEAD seal", "crypto", sub="AAD: frame ID, chunk index", icon="lock")
    f.block(568, y, 106, bh, "UDP datagram", "plain", sub="at most 1472 B")
    for a, b in ((128, 150), (290, 330), (344, 384), (540, 568)):
        f.edge([(a, c), (b, c)], "data")
    f.block(150, 84, 140, 22, "Encrypted recorder", "crypto")
    f.edge([(220, y + bh), (220, 84)], "data")
    f.text(384, 78, 310, 26, "the capture time of each frame travels inside the ciphertext;<br>the recorder receives the same encoded frames", align="left")
    # channel
    gy = 140.0
    xr = 696
    f.icon("adversary", 498, 117, 18)
    f.text(520, 119, 168, 14, "untrusted network (Wi-Fi / IP)", align="left")
    # GCS, right to left
    f.card(E, gy, W - 2 * E, H - E - gy, "GCS: verify, reassemble, decode", icon="ground_station")
    y2 = gy + 34
    c2 = y2 + bh / 2
    f.block(536, y2, 140, bh, "AEAD open", "crypto", sub="replay window, tag", icon="lock_open")
    f.block(346, y2, 160, bh, "Reassembly", "plain", sub="by frame ID, 150 ms buffer", icon="frame_buffer")
    f.block(180, y2, 136, bh, "H.264 decoder", "plain", sub="ffmpeg, low delay", icon="cpu")
    f.block(10, y2, 140, bh, "Decoded frames", "data", sub="live view, detector", icon="display")
    f.edge([(674, c), (xr, c), (xr, c2), (676, c2)], "data")
    for a, b in ((536, 506), (346, 316), (180, 150)):
        f.edge([(a, c2), (b, c2)], "data")
    f.text(160, y2 + bh + 6, 516, 26, "an incomplete frame is dropped and the decoder waits for the next IDR;<br>"
                                      "a jump of more than 90 frame numbers resynchronises at the next IDR")
    return f


def fig08_perception_hitl():
    W, H = W2, 252.0
    f = Fig("fig08_perception_hitl", W, H, "Perception and the human-in-the-loop path on the ground station")
    f.card(E, E, W - 2 * E, H - 2 * E, "Ground control station", icon="ground_station")
    f.block(10, 44, 104, 90, "Decoded frames", "data", sub="each with its<br>capture time")
    # perception
    px, pw = 132, 386
    f.card(px, 30, pw, 172, "Perception (CPU)", icon="model", fill=CARD2)
    ya, yb, yc, bh = 58, 104, 156, 34
    f.block(px + 10, ya, 126, bh, "Finder", "plain", sub="OWLv2, text query", icon="finder")
    f.block(px + 160, ya, 218, bh, "Confirmation", "plain", sub="strong hit at once, weak hit after 2 passes")
    f.block(px + 10, yb, 126, bh, "Detector", "plain", sub="YOLOE-11s or 11L", icon="detector")
    f.block(px + 160, yb, 100, bh, "Tracker", "plain", sub="ByteTrack")
    f.block(px + 282, yb, 96, bh, "Label vote", "plain", sub="3 hits to confirm")
    f.block(px + 10, yc, 126, bh, "Visual prompt", "plain", sub="from the taught box", icon="teach")
    f.block(px + 160, yc, 218, bh, "SQLite store", "plain", sub="tracks, detections, finder passes", icon="database")
    f.edge([(114, ya + 17), (px + 10, ya + 17)], "data")
    f.edge([(114, yb + 17), (px + 10, yb + 17)], "data")
    f.edge([(px + 136, ya + 17), (px + 160, ya + 17)], "data")
    f.edge([(px + 136, yb + 17), (px + 160, yb + 17)], "data")
    f.edge([(px + 260, yb + 17), (px + 282, yb + 17)], "data")
    f.edge([(px + 73, yc), (px + 73, yb + bh)], "cmd")
    f.edge([(px + 330, yb + bh), (px + 330, yc)], "data")
    # dashboard
    dx = 536
    dw = W - E - 8 - dx
    f.card(dx, 30, dw, 172, "Dashboard", icon="dashboard", fill=CARD2)
    f.block(dx + 10, ya, dw - 20, yb + bh - ya, "Overlay", "data", sub="boxes placed by the<br>capture time of<br>each frame")
    f.block(dx + 10, yc, dw - 20, bh, "Operator", "ink", sub="views, decides, acts", icon="operator")
    f.edge([(px + 378, ya + 17), (dx + 10, ya + 17)], "data")
    f.edge([(px + 378, yb + 17), (dx + 10, yb + 17)], "data")
    om = dx + dw / 2
    f.edge([(om, yb + bh), (om, yc)], "data")
    # operator feedback
    f.edge([(om - 30, yc + bh), (om - 30, 211), (px + 73, 211), (px + 73, yc + bh)], "cmd")
    f.text(px + 83, 213, 380, 12, "TEACH: the operator draws a box around an object; words and profile are set here too", align="left")
    f.block(10, 220, 190, 24, "Control stream to the UAV (AEAD)", "ink")
    f.edge([(om + 30, yc + bh), (om + 30, 232), (200, 232)], "cmd")
    f.text(210, 234, 420, 12, "commands: live, record, capture, mode, rekey, ratchet", align="left")
    return f


def fig09_recording_at_rest():
    W, H = W1, 336.0
    f = Fig("fig09_recording_at_rest", W, H, "Encrypted recordings at rest: written on the UAV, readable only on the GCS")
    f.card(E, E, W - 2 * E, 200, "UAV: write an encrypted recording", icon="uav")
    lx, lw, mx, mw, rx = 8, 92, 120, 96, 236
    rw = W - E - 8 - rx
    CEK, KEK = "<i>CEK</i>", "<i>KEK</i>"
    f.block(lx, 30, lw, 30, "<i>ek</i>", "ink", sub="GCS recording key", bold=False)
    f.block(mx, 30, mw, 30, "ML-KEM-1024", "crypto", sub="Encaps")
    f.block(rx, 30, rw, 30, "<i>ct</i>", "plain", sub="1568 B, stored", bold=False)
    f.edge([(lx + lw, 45), (mx, 45)], "key")
    f.edge([(mx + mw, 45), (rx, 45)], "ctrl")
    f.block(mx, 74, mw, 30, "HKDF", "crypto", sub="salt: header, <i>ct</i>")
    f.edge([(mx + mw / 2, 60), (mx + mw / 2, 74)], "key")
    f.text(mx + mw / 2 + 5, 61, 20, 12, "<i>ss</i>", align="left")
    f.block(lx, 118, lw, 30, CEK, "ink", sub="32 random bytes", bold=False)
    f.block(mx, 118, mw, 30, "AES-256-GCM", "crypto", sub=f"wrap the {CEK}")
    f.block(rx, 118, rw, 30, f"wrapped {CEK}", "plain", sub="48 B, stored", bold=False)
    f.edge([(mx + mw / 2, 104), (mx + mw / 2, 118)], "key")
    f.text(mx + mw / 2 + 5, 105, 30, 12, KEK, align="left")
    f.edge([(lx + lw, 133), (mx, 133)], "key")
    f.edge([(mx + mw, 133), (rx, 133)], "ctrl")
    f.block(lx, 168, lw, 24, "H.264 frames", "plain")
    f.block(mx, 154, mw, 38, "AES-256-GCM", "crypto", sub="per segment <i>i</i>")
    f.block(rx, 158, rw, 30, "segments", "plain", sub='nonce 0<sup style="font-size:8.67px;line-height:0">32</sup> || <i>i</i>', bold=False)
    f.edge([(lx + lw / 2, 148), (lx + lw / 2, 161), (mx, 161)], "key")
    f.edge([(lx + lw, 180), (mx, 180)], "data")
    f.edge([(mx + mw, 173), (rx, 173)], "data")
    # file layout (recording/recorder.py)
    f.text(E, 206, W - 2 * E, 14, "File on the SD card (.k6grec)", fs=FS_B, bold=True, align="left", color=INK2)
    parts = [("K6GREC01", 56, "plain"), ("header", 42, "plain"), ("<i>ct</i>", 26, "plain"), (f"wrapped {CEK}", 70, "crypto"),
             ("segment 0", 54, "crypto"), ("...", 20, "crypto"), ("last segment", W - 2 * E - 268, "crypto")]
    x = E
    for name, w, kind in parts:
        f.block(x, 222, w, 24, name, kind, fs=FS_N, rounded=False, fill=CARD2 if kind == "crypto" else WHITE)
        x += w
    f.text(E, 249, W - 2 * E, 12, "the UAV keeps no key that can decrypt a finished recording")
    # GCS
    gy = 268.0
    f.card(E, gy, W - 2 * E, H - E - gy, "GCS: decrypt", icon="ground_station")
    bw = 72
    gap = (W - 2 * E - 16 - 4 * bw) / 3
    steps = [("<i>dk</i>", "GCS only", "ink"), ("Decaps", f"HKDF, {KEK}", "crypto"), ("Unwrap", f"the {CEK}", "crypto"),
             ("Decrypt", "to MP4", "crypto")]
    for i, (t, s, kind) in enumerate(steps):
        bx = E + 8 + i * (bw + gap)
        f.block(bx, gy + 28, bw, 30, t, kind, sub=s, bold=False)
        if i:
            f.edge([(bx - gap, gy + 43), (bx, gy + 43)], "key" if i < 3 else "data")
    return f


def fig10_evaluation_workflow():
    W, H = W2, 236.0
    f = Fig("fig10_evaluation_workflow", W, H, "Evaluation workflow: measurements on the prototype calibrate the network simulation")
    cb = 200.0
    x1, w1, x2, w2, x3, w3 = E, 196, 212.67, 142, 370.67, 196
    x4 = 582.67
    w4 = W - E - x4
    f.card(x1, E, w1, cb - E, "1&nbsp; Prototype (measured)", icon="cpu")
    f.card(x2, E, w2, cb - E, "2&nbsp; Calibration", icon="calibrate")
    f.card(x3, E, w3, cb - E, "3&nbsp; Simulation (ns-3)", icon="swarm")
    f.card(x4, E, w4, cb - E, "4&nbsp; Results", icon="chart")
    r = (30, 84, 138)
    # 1 prototype
    b1, bw1 = x1 + 8, w1 - 16
    f.block(b1, r[0], bw1, 30, "UAV: Raspberry Pi 4B", "plain", sub="Cortex-A72, liboqs, OpenSSL", icon="uav")
    f.block(b1, r[1], bw1, 30, "GCS: laptop", "plain", sub="same protocol stack", icon="ground_station")
    m1 = b1 + bw1 / 2
    f.edge([(m1, r[0] + 30), (m1, r[1])], "data", "both")
    f.text(m1 + 6, r[0] + 36, 60, 12, "Wi-Fi / IP", align="left")
    f.block(b1, r[2], bw1, 44, "Measured", "ink", sub="handshake, cached rekey,<br>AEAD, video, telemetry", icon="clock")
    f.edge([(m1, r[1] + 30), (m1, r[2])], "ctrl")
    # 2 calibration
    b2, bw2 = x2 + 8, w2 - 16
    m2 = b2 + bw2 / 2
    f.block(b2, r[0], bw2, 30, "Timing data", "plain", sub="CSV per operation")
    f.block(b2, r[1], bw2, 30, "Hardware profile", "plain", sub="delay per primitive")
    f.block(b2, r[2], bw2, 30, "Model parameters", "plain", sub="sizes from FIPS 203, 204")
    f.edge([(m2, r[0] + 30), (m2, r[1])], "ctrl")
    f.edge([(m2, r[1] + 30), (m2, r[2])], "ctrl")
    f.edge([(b1 + bw1, r[2] + 22), (x1 + w1 + 8, r[2] + 22), (x1 + w1 + 8, r[0] + 15), (b2, r[0] + 15)], "ctrl")
    # 3 simulation
    b3, bw3 = x3 + 8, w3 - 16
    m3 = b3 + bw3 / 2
    f.block(b3, r[0], bw3, 30, "UAV swarm scenario", "plain", sub="mobility, handover, traffic")
    f.block(b3, r[1], bw3, 30, "PQC security module", "crypto", sub="handshake, key cache, AEAD layer")
    f.block(b3, r[2], bw3, 30, "NR radio and channel", "plain", sub="5G-LENA, simulated only")
    f.edge([(m3, r[0] + 30), (m3, r[1])], "ctrl", "both")
    f.edge([(m3, r[1] + 30), (m3, r[2])], "ctrl", "both")
    f.edge([(b2 + bw2, r[2] + 15), (x2 + w2 + 8, r[2] + 15), (x2 + w2 + 8, r[1] + 15), (b3, r[1] + 15)], "ctrl")
    # 4 results
    b4, bw4 = x4 + 8, w4 - 16
    f.block(b4, r[0], bw4, 44, "Swarm results", "data", sub="latency, delivery,<br>queueing, energy")
    f.block(b4, r[2] + 6, bw4, 30, "Validation", "data", sub="hardware vs simulation")
    f.edge([(b3 + bw3, r[0] + 15), (b4, r[0] + 15)], "data")
    f.edge([(b3 + bw3, r[1] + 15), (x3 + w3 + 8, r[1] + 15), (x3 + w3 + 8, r[2] + 21), (b4, r[2] + 21)], "data")
    vm = b4 + bw4 / 2
    f.edge([(m1, r[2] + 44), (m1, 218), (vm, 218), (vm, r[2] + 36)], "ctrl")
    f.text(m1 + 10, 204, 420, 12, "measured values for the one-to-one comparison", align="left")
    f.text(m1 + 10, 221, 520, 12, "the simulator models cryptography by message size and calibrated delay; it does not execute it", align="left")
    return f


FIGURES = [fig01_system_architecture, fig02_threat_model, fig03_handshake, fig04_key_schedule, fig05_session_lifecycle,
           fig06_record_layer, fig07_video_pipeline, fig08_perception_hitl, fig09_recording_at_rest, fig10_evaluation_workflow]
