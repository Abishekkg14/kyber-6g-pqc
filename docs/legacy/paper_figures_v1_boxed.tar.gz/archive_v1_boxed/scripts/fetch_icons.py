#!/usr/bin/env python3
"""Search and fetch the line icons used in the paper figures.

Source: Tabler Icons (https://tabler.io/icons), MIT licence, fetched from the jsDelivr mirror of the npm package at a
pinned version. One icon family is used on purpose: every Tabler outline icon is drawn on the same 24 x 24 grid with
the same stroke, caps and joins, which is what gives the figures one visual language. (SVGRepo and The Noun Project
mix many authors, styles and licences; The Noun Project also needs an API key and per-icon attribution.)

For every role needed in the figures the script
  1. looks up the preferred icon names in the package index, and if none exists searches the index by keyword;
  2. downloads the outline SVG;
  3. checks that it really is a monoline icon (stroke only, no fills) and normalises it:
     stroke colour = ink (#1E293B), stroke width 2 on the 24-unit grid (= 1.5 pt when drawn 18 pt wide; the figure
     generator rescales the width so the stroke is 1.5 pt at whatever size the icon is placed), round caps and joins;
  4. writes assets/icons/<role>.svg, assets/icons/manifest.json and assets/ICON_ATTRIBUTION.md.

Usage:  python3 scripts/fetch_icons.py [--force]
"""
import hashlib
import json
import re
import sys
import urllib.request
from pathlib import Path

VERSION = "3.48.0"
CDN = f"https://cdn.jsdelivr.net/npm/@tabler/icons@{VERSION}"
INK = "#1E293B"
ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "assets" / "icons"

# role -> (preferred icon names in order, search keywords used when none of the names exists)
ROLES = {
    # input sensors / video / frame buffer
    "camera": (["camera"], "camera photo"),
    "video": (["video"], "video film"),
    "frame_buffer": (["stack-2", "stack"], "stack layers"),
    "image": (["photo"], "photo image picture"),
    # microcontroller / edge unit / microprocessor
    "cpu": (["cpu"], "cpu processor chip"),
    "uav": (["drone"], "drone uav quadcopter"),
    # cloud / ground station / server node
    "ground_station": (["device-laptop"], "laptop computer"),
    "server": (["server"], "server rack"),
    "cloud": (["cloud"], "cloud"),
    "database": (["database"], "database storage"),
    "dashboard": (["layout-dashboard"], "dashboard layout"),
    # key / lock / RNG / KDF
    "key": (["key"], "key password"),
    "lock": (["lock"], "lock secure"),
    "lock_open": (["lock-open"], "unlock open"),
    "shield": (["shield-lock"], "shield security"),
    "shield_check": (["shield-check"], "shield check verified"),
    "signature": (["writing-sign", "signature"], "signature sign"),
    "certificate": (["certificate"], "certificate identity"),
    "rng": (["arrows-shuffle", "arrows-random"], "shuffle random"),      # the dice icons have filled dots: rejected
    "kdf": (["arrows-split-2", "arrows-split"], "split derive branch"),
    "hash": (["hash"], "hash number"),
    "rekey": (["refresh"], "refresh reload rotate"),
    "ratchet": (["rotate-clockwise-2", "rotate-clockwise"], "rotate clockwise"),
    # radio / transceiver / telemetry
    "antenna": (["antenna"], "antenna radio"),
    "wifi": (["wifi"], "wifi wireless"),
    "broadcast": (["broadcast"], "broadcast signal"),
    "gnss": (["satellite"], "satellite gps"),
    "position": (["map-pin"], "map pin location"),
    "telemetry": (["activity"], "activity pulse heartbeat"),
    "imu": (["compass"], "compass direction"),
    # document / plaintext / ciphertext / bitstream
    "plaintext": (["file-text"], "file text document"),
    "ciphertext": (["file-digit", "file-code"], "file digit binary"),
    "bitstream": (["binary"], "binary bits"),
    "packet": (["package"], "package box parcel"),
    "sd_card": (["device-sd-card"], "sd card memory"),
    "recording": (["player-record"], "record"),
    "movie": (["movie"], "movie film clip"),
    # perception and operator
    "detector": (["object-scan", "scan", "viewfinder"], "scan detect object"),   # focus-2 has a filled dot: rejected
    "finder": (["search"], "search find"),
    "teach": (["school"], "school teach learn"),
    "model": (["brain"], "brain ai model"),
    "operator": (["user"], "user person"),
    "eye": (["eye"], "eye view"),
    "command": (["hand-click"], "click hand command"),
    # threat model and evaluation
    "adversary": (["spy"], "spy attacker incognito"),
    "warning": (["alert-triangle"], "alert warning"),
    "clock": (["clock"], "clock time"),
    "chart": (["chart-line"], "chart line graph"),
    "calibrate": (["adjustments-horizontal", "adjustments"], "adjust settings sliders"),
    "swarm": (["topology-star-3", "topology-star"], "topology network star"),
    "simulation": (["cpu-2", "terminal-2"], "terminal simulation"),
    "display": (["device-desktop"], "desktop monitor display"),
}


def get(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "kyber6g-paper-figures/1.0"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.read()


def search(index: dict, words: str):
    """Rank the icons of the index by how many of the keywords appear in their name or tags."""
    want = words.split()
    scored = []
    for name, meta in index.items():
        if "outline" not in (meta.get("styles") or {}):
            continue
        hay = {name, *name.split("-"), *(str(t).lower() for t in meta.get("tags") or [])}
        score = sum(2 if w == name else 1 for w in want if w in hay)
        if score:
            scored.append((-score, len(name), name))
    return [n for _, _, n in sorted(scored)]


def normalise(svg: str) -> str:
    """Stroke-only, ink-coloured, 24-unit grid, no bounding helper path, no classes."""
    if 'viewBox="0 0 24 24"' not in svg:
        raise ValueError("not on the 24 x 24 grid")
    body = re.search(r"<svg[^>]*>(.*)</svg>", svg, re.S).group(1)
    body = re.sub(r"<!--.*?-->", "", body, flags=re.S)
    body = re.sub(r'<path[^>]*stroke="none"[^>]*/>', "", body)            # the invisible 24 x 24 bounding path
    shapes = re.findall(r"<(path|circle|rect|line|polyline|polygon|ellipse)\b([^>]*)/?>", body)
    if not shapes:
        raise ValueError("no drawable elements")
    for tag, attrs in shapes:
        fill = re.search(r'fill="([^"]*)"', attrs)
        if fill and fill.group(1) not in ("none",):
            raise ValueError(f"filled <{tag}> (not a monoline icon)")
    body = "".join(line.strip() for line in body.strip().splitlines())
    return ('<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" '
            f'stroke="{INK}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{body}</svg>\n')


def main():
    force = "--force" in sys.argv
    OUT.mkdir(parents=True, exist_ok=True)
    index = json.loads(get(f"{CDN}/icons.json"))
    print(f"Tabler Icons {VERSION}: {len(index)} icons in the index")
    manifest, problems = {}, []
    for role, (names, words) in ROLES.items():
        cands = [n for n in names if "outline" in (index.get(n, {}).get("styles") or {})]
        how = "preferred"
        if not cands:
            cands, how = search(index, words)[:5], f"search '{words}'"
        done = False
        for name in cands:
            url = f"{CDN}/icons/outline/{name}.svg"
            dst = OUT / f"{role}.svg"
            try:
                svg = normalise(get(url).decode())
            except Exception as e:                                         # try the next candidate
                problems.append(f"{role}: {name}: {e}")
                continue
            if force or not dst.exists() or dst.read_text() != svg:
                dst.write_text(svg)
            manifest[role] = {"icon": name, "source": url, "selected_by": how, "tags": (index[name].get("tags") or [])[:6],
                              "sha256": hashlib.sha256(svg.encode()).hexdigest()}
            print(f"  {role:15s} <- {name:26s} ({how})")
            done = True
            break
        if not done:
            problems.append(f"{role}: NO ICON FOUND")
    (OUT / "manifest.json").write_text(json.dumps(
        {"family": "Tabler Icons", "version": VERSION, "licence": "MIT", "homepage": "https://tabler.io/icons",
         "style": "outline, 24 x 24 grid, stroke 2 (= 1.5 pt at 18 pt), round caps and joins, no fills",
         "icons": manifest}, indent=1) + "\n")
    lines = ["# Icon attribution", "",
             f"All icons in `assets/icons/` are from **Tabler Icons {VERSION}** (https://tabler.io/icons), "
             "Copyright (c) 2020-2026 Paweł Kuna, released under the MIT licence. They were recoloured to the figure "
             "ink colour; the geometry is unchanged. The MIT licence permits use in publications; no per-icon "
             "attribution is required, this file records the source for reproducibility.", "",
             "| Role in the figures | Tabler icon | Source |", "|---|---|---|"]
    lines += [f"| {r} | `{m['icon']}` | {m['source']} |" for r, m in manifest.items()]
    (ROOT / "assets" / "ICON_ATTRIBUTION.md").write_text("\n".join(lines) + "\n")
    print(f"{len(manifest)} of {len(ROLES)} icons in {OUT}")
    for p in problems:
        print("  note:", p)
    return 0 if len(manifest) == len(ROLES) else 1


if __name__ == "__main__":
    sys.exit(main())
