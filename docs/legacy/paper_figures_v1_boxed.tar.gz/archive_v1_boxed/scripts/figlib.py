#!/usr/bin/env python3
"""figlib: describe a figure in Python, get an editable draw.io file and a list of layout problems.

Units. Everything is in draw.io units ("px"). The build step scales the exported PDF so that one unit is exactly
0.75 pt, i.e. the full design width W1 / W2 comes out as exactly 90 mm / 190 mm. In those terms:
    12 px = 9 pt (headers)   10.67 px = 8 pt (block labels)   9.33 px = 7 pt (notes)   8.67 px = 6.5 pt (minimum)
    1.33 px = 1 pt (card borders)   1.6 px = 1.2 pt (lines)   2 px = 1.5 pt (icon strokes, emphasis)

Style rules built in (Elsevier artwork + the muted palette of this paper):
    Arial only; no text below 6.5 pt; no pure black; orthogonal connectors with arc line jumps and small filled
    triangular heads; cards #F8FAFC with a 1 pt #94A3B8 border; ink #1E293B / #0F172A; two accents only:
    navy #1E3A8A = data path (solid), crimson #991B1B = keys and cryptographic operations (dashed when a line),
    so the two stay apart in greyscale by line style, not by hue.
"""
import base64
import html as _html
import re
from pathlib import Path

from PIL import ImageFont

ROOT = Path(__file__).resolve().parent.parent
MM = 96 / 25.4
W1, W2 = 90 * MM, 190 * MM                      # 340.16 and 718.11 units
PT = 4 / 3                                      # units per typographic point

INK, INK2 = "#1E293B", "#0F172A"
CARD, CARD2, WHITE = "#F8FAFC", "#F1F5F9", "#FFFFFF"
BORDER = "#94A3B8"
NAVY, CRIMSON = "#1E3A8A", "#991B1B"
PALETTE = {INK, INK2, CARD, CARD2, WHITE, BORDER, NAVY, CRIMSON, "none"}

FS_H, FS_B, FS_N, FS_MIN = 12.0, 10.67, 9.33, 8.67          # 9, 8, 7 and 6.5 pt
SW_CARD, SW_LINE, SW_BOLD = 1.33, 1.6, 2.0                    # 1, 1.2 and 1.5 pt
# Arrowheads: small filled triangles, 4 pt long and 3 pt wide. Two ways to draw them (sizes measured on the output):
#   "shape"   a separate triangle shape that belongs to the block it points at: 3.97 x 3.00 pt (the default)
#   "marker"  draw.io's own "blockThin" end marker, part of the connector and so nicer to edit by hand, but it is
#             stroked with the line width and cannot have both dimensions right: size 0.6 gives 4.12 x 2.76 pt,
#             size 1.2 gives 4.58 x 3.06 pt
HEAD_STYLE = "shape"
MARKER, MARKER_SIZE = "blockThin", 0.6
HEAD_L, HEAD_W, HEAD_OVERLAP = 5.33, 4.0, 0.6                 # "shape": length 4 pt, width 3 pt; the line ends 0.6 units inside

_FONT_DIRS = ["/usr/local/share/fonts/windows-core", "/mnt/c/Windows/Fonts", "/usr/share/fonts/truetype/liberation"]
_FONT_FILES = {(False, False): ["arial.ttf", "LiberationSans-Regular.ttf"], (True, False): ["arialbd.ttf", "LiberationSans-Bold.ttf"],
               (False, True): ["ariali.ttf", "LiberationSans-Italic.ttf"], (True, True): ["arialbi.ttf", "LiberationSans-BoldItalic.ttf"]}
_fonts = {}


def _font(bold, italic):
    key = (bool(bold), bool(italic))
    if key not in _fonts:
        for d in _FONT_DIRS:
            for f in _FONT_FILES[key]:
                p = Path(d) / f
                if p.exists():
                    _fonts[key] = ImageFont.truetype(str(p), 200)
                    return _fonts[key]
        raise RuntimeError("no Arial / Liberation Sans font found for text measurement")
    return _fonts[key]


_TAG = re.compile(r"<(/?)(b|i|sub|sup|br|span|font)\b([^>]*)>", re.I)


def text_lines(html, fs, bold=False, italic=False):
    """Split label HTML into lines of (text, size, bold, italic) runs. Only the tags figlib itself writes are known."""
    lines, stack, pos = [[]], [(fs, bold, italic)], 0
    for m in _TAG.finditer(html):
        if m.start() > pos:
            lines[-1].append((_html.unescape(html[pos:m.start()]), *stack[-1]))
        pos = m.end()
        close, tag, attrs = m.group(1), m.group(2).lower(), m.group(3)
        if tag == "br":
            lines.append([])
            continue
        if close:
            if len(stack) > 1:
                stack.pop()
            continue
        s, b, i = stack[-1]
        b, i = b or tag == "b", i or tag == "i"
        if tag in ("sub", "sup"):
            s = 0.83 * s
        size = re.search(r"font-size:\s*([\d.]+)px", attrs)
        if size:
            s = float(size.group(1))
        stack.append((s, b, i))
    if pos < len(html):
        lines[-1].append((_html.unescape(html[pos:]), *stack[-1]))
    return lines


def measure(html, fs, bold=False, italic=False):
    """(width, height, smallest font size) of a label as the browser lays it out (line height 1.2)."""
    lines = text_lines(html, fs, bold, italic)
    width = max((sum(_font(b, i).getlength(t) * s / 200 for t, s, b, i in line) for line in lines), default=0)
    sizes = [s for line in lines for t, s, b, i in line if t.strip()]
    return width, 1.2 * fs * len(lines), min(sizes, default=fs)


# ---- small HTML helpers so that the math conventions are applied the same way everywhere ----
def var(name, sub=None, sup=None):
    """An italic variable with optional upright subscript / superscript (never below 6.5 pt)."""
    out = f"<i>{name}</i>"
    if sub is not None:
        out += f'<sub style="font-size:{FS_MIN}px;line-height:0">{sub}</sub>'
    if sup is not None:
        out += f'<sup style="font-size:{FS_MIN}px;line-height:0">{sup}</sup>'
    return out


def small(text, fs=FS_N):
    return f'<span style="font-size:{fs}px">{text}</span>'


def _esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def _n(v):
    return f"{round(v, 2):g}"


class Fig:
    def __init__(self, name, width, height, caption=""):
        self.name, self.W, self.H, self.caption = name, width, height, caption
        self.cards, self.blocks, self.ops, self.icons, self.texts, self.lines, self.heads = [], [], [], [], [], [], []
        self.labels = []                 # (x0, y0, x1, y1, owner id, description) of every piece of text
        self.issues = []
        self._n = 0

    # ------------------------------------------------------------------ vertices
    def _id(self, prefix):
        self._n += 1
        return f"{prefix}{self._n}"

    def card(self, x, y, w, h, title=None, icon=None, fill=CARD, stroke=BORDER, dashed=False, arc=8, title_fs=FS_H,
             title_color=INK2):
        cid = self._id("card")
        style = (f"rounded=1;arcSize={arc};absoluteArcSize=1;html=1;container=1;collapsible=0;recursiveResize=0;"
                 f"fillColor={fill};strokeColor={stroke};strokeWidth={SW_CARD};" + ("dashed=1;dashPattern=4 3;" if dashed else ""))
        self.cards.append(dict(id=cid, x=x, y=y, w=w, h=h, value="", style=style))
        tx = x + 7
        if icon:
            self.icon(icon, x + 6, y + 5, 18)
            tx = x + 28
        if title:
            self.text(tx, y + 5, w - (tx - x) - 6, 18, title, fs=title_fs, align="left", bold=True, color=title_color)
        return cid

    def tag(self, n, cx, cy, d=13, color=INK):
        """A small numbered circle, used to key connectors to a list of explanations."""
        tid = self._id("tag")
        style = (f"ellipse;html=1;fillColor={WHITE};strokeColor={color};strokeWidth={SW_CARD};fontFamily=Arial;fontSize={FS_MIN};"
                 f"fontColor={color};fontStyle=1;spacing=0;")
        self.ops.append(dict(id=tid, x=cx - d / 2, y=cy - d / 2, w=d, h=d, value=str(n), style=style, shape="ellipse"))
        return tid

    def block(self, x, y, w, h, label, kind="plain", sub=None, icon=None, bold=None, fs=FS_B, fill=WHITE, align="center",
              sub_fs=FS_N, dashed=False, rounded=True):
        """A process block. kind: plain (grey border) | data (navy) | crypto (crimson) | ink (dark border)."""
        bid = self._id("blk")
        stroke, sw = {"plain": (BORDER, SW_CARD), "data": (NAVY, SW_LINE), "crypto": (CRIMSON, SW_LINE), "ink": (INK, SW_LINE)}[kind]
        bold = (sub is not None) if bold is None else bold
        value = (f"<b>{label}</b>" if bold else label) + (f"<br>{small(sub, sub_fs)}" if sub else "")
        left = 0
        if icon:
            isz = 18
            self.icon(icon, x + 6, y + (h - isz) / 2, isz, color={"data": NAVY, "crypto": CRIMSON}.get(kind, INK))
            left = isz + 8
        style = (f"rounded={1 if rounded else 0};arcSize=6;absoluteArcSize=1;html=1;fillColor={fill};strokeColor={stroke};strokeWidth={sw};"
                 f"fontFamily=Arial;fontSize={fs};fontColor={INK2};align={align};verticalAlign=middle;spacing=0;"
                 f"spacingLeft={_n(left + (5 if align == 'left' else 0))};spacingRight={5 if align == 'right' else 0};"
                 + ("dashed=1;dashPattern=4 3;" if dashed else ""))
        self.blocks.append(dict(id=bid, x=x, y=y, w=w, h=h, value=value, style=style, shape="rect"))
        tw, th, smallest = measure(value, fs)
        avail = w - left - (10 if align != "center" else 6)
        if tw > avail:
            self.issues.append(f"label wider than its block by {tw - avail:.1f} px: {re.sub('<[^>]+>', ' ', value)!r}")
        if th > h - 2:
            self.issues.append(f"label taller than its block: {re.sub('<[^>]+>', ' ', value)!r}")
        self._font_ok(smallest, value)
        cx = x + left + (w - left) / 2
        x0 = {"center": cx - tw / 2, "left": x + left + 5, "right": x + w - 5 - tw}[align]
        self.labels.append((x0, y + h / 2 - th / 2, x0 + tw, y + h / 2 + th / 2, bid, value))
        return bid

    def text(self, x, y, w, h, html, fs=FS_N, align="center", valign="middle", color=INK, bold=False, italic=False):
        tid = self._id("txt")
        style = (f"text;html=1;strokeColor=none;fillColor=none;align={align};verticalAlign={valign};spacing=0;"
                 f"fontFamily=Arial;fontSize={fs};fontColor={color};fontStyle={(1 if bold else 0) + (2 if italic else 0)};")
        self.texts.append(dict(id=tid, x=x, y=y, w=w, h=h, value=html, style=style))
        tw, th, smallest = measure(html, fs, bold, italic)
        self._font_ok(smallest, html)
        x0 = {"left": x, "center": x + w / 2 - tw / 2, "right": x + w - tw}[align]
        y0 = {"top": y, "middle": y + h / 2 - th / 2, "bottom": y + h - th}[valign]
        self.labels.append((x0, y0, x0 + tw, y0 + th, tid, html))
        if x0 < -0.5 or x0 + tw > self.W + 0.5 or y0 < -0.5 or y0 + th > self.H + 0.5:
            self.issues.append(f"text outside the figure: {re.sub('<[^>]+>', ' ', html)!r}")
        return tid

    def icon(self, role, x, y, size=24, color=INK):
        """A line icon from assets/icons. The stroke is 1.5 pt (2 units) at whatever size the icon is placed."""
        svg = (ROOT / "assets" / "icons" / f"{role}.svg").read_text()
        svg = svg.replace('stroke="#1E293B"', f'stroke="{color}"').replace('stroke-width="2"', f'stroke-width="{round(SW_BOLD * 24 / size, 3)}"')
        b64 = base64.b64encode(svg.encode()).decode()
        iid = self._id("ico")
        self.icons.append(dict(id=iid, x=x, y=y, w=size, h=size, value="",
                               style=f"shape=image;html=1;imageAspect=0;aspect=fixed;image=data:image/svg+xml,{b64};"))
        return iid

    def op(self, kind, cx, cy, d=14, color=CRIMSON):
        """Circular operator: 'xor' (circle with a plus), 'slice' (circle with a bar: split into chunks / fields),
        'concat' (circle with ||)."""
        oid = self._id("op")
        base = f"html=1;fillColor={WHITE};strokeColor={color};strokeWidth={SW_LINE};perimeter=ellipsePerimeter;"
        value = ""
        if kind == "xor":
            style = "shape=orEllipse;" + base
        elif kind == "slice":
            style = "shape=lineEllipse;line=vertical;" + base
        elif kind == "concat":
            style = "ellipse;" + base + f"fontFamily=Arial;fontSize={FS_MIN};fontColor={color};fontStyle=1;spacing=0;spacingBottom=1;"
            value = "||"
        else:
            raise ValueError(kind)
        self.ops.append(dict(id=oid, x=cx - d / 2, y=cy - d / 2, w=d, h=d, value=value, style=style, shape="ellipse"))
        return oid

    def _font_ok(self, smallest, html):
        if smallest < FS_MIN - 0.01:
            self.issues.append(f"text below 6.5 pt ({smallest * 0.75:.1f} pt): {re.sub('<[^>]+>', ' ', html)!r}")

    # --------------------------------------------------------------------- lines
    def edge(self, pts, kind="data", arrow="end", dashed=None, color=None, width=SW_LINE, attach=True, jump=True):
        """An orthogonal connector through the given points. kind: data (navy, solid) | key (crimson, dashed) |
        cmd (ink, dotted: operator commands and the control stream) | ctrl (ink, solid: neutral "leads to") |
        rule (grey, no head). The three line styles keep data, keys and commands apart in greyscale.
        jump=False for ticks and rules that touch other lines on purpose."""
        pts = [(round(float(x), 2), round(float(y), 2)) for x, y in pts]
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
            if abs(x0 - x1) > 0.005 and abs(y0 - y1) > 0.005:
                self.issues.append(f"connector segment is not orthogonal: {(x0, y0)} -> {(x1, y1)}")
        col = color or {"data": NAVY, "key": CRIMSON, "ctrl": INK, "cmd": INK, "rule": BORDER}[kind]
        dashed = (kind in ("key", "cmd")) if dashed is None else dashed
        if kind == "rule":
            arrow = "none"
        style = (f"edgeStyle=orthogonalEdgeStyle;rounded=0;html=1;strokeColor={col};strokeWidth={width};"
                 + ("jumpStyle=arc;jumpSize=6;" if jump and kind != "rule" else "")
                 + (f"dashed=1;dashPattern={'1 2' if kind == 'cmd' else '4 3'};" if dashed else ""))
        src = self._terminal(pts[0]) if attach else None
        dst = self._terminal(pts[-1]) if attach else None
        draw = list(pts)                 # the line as drawn; with triangle shapes it stops inside the base of each head
        if HEAD_STYLE == "shape":
            style += "endArrow=none;startArrow=none;"
            if arrow in ("end", "both"):
                draw[-1] = self._head(pts[-1], pts[-2], col, dst)
            if arrow == "both":
                draw[0] = self._head(pts[0], pts[1], col, src)
        else:
            marker = f"{MARKER};{{0}}Fill=1;{{0}}Size={MARKER_SIZE};"
            style += ("endArrow=" + marker.format("end") if arrow in ("end", "both") else "endArrow=none;")
            style += ("startArrow=" + marker.format("start") if arrow == "both" else "startArrow=none;")
        self.lines.append(dict(id=self._id("edge"), pts=pts, draw=draw, style=style, src=src, dst=dst, kind=kind, arrow=arrow))

    def _head(self, tip, prev, col, owner):
        """A 4 pt x 3 pt triangle with its tip at `tip`, pointing away from `prev`. Returns where the line has to end.
        The head belongs to the block it points at, so it moves with that block in the editor."""
        dx, dy = tip[0] - prev[0], tip[1] - prev[1]
        if abs(dx) + abs(dy) < HEAD_L + 1.5:
            self.issues.append(f"connector end {prev} -> {tip} is too short for an arrowhead")
        ux, uy = (dx > 0.005) - (dx < -0.005), (dy > 0.005) - (dy < -0.005)
        if ux:
            x, y, w, h = (tip[0] - HEAD_L if ux > 0 else tip[0]), tip[1] - HEAD_W / 2, HEAD_L, HEAD_W
        else:
            x, y, w, h = tip[0] - HEAD_W / 2, (tip[1] - HEAD_L if uy > 0 else tip[1]), HEAD_W, HEAD_L
        d = {(1, 0): "east", (-1, 0): "west", (0, 1): "south", (0, -1): "north"}.get((ux, uy), "east")
        self.heads.append(dict(id=self._id("head"), x=x, y=y, w=w, h=h, value="", owner=owner,
                               style=f"shape=triangle;direction={d};html=1;fillColor={col};strokeColor=none;perimeter=none;connectable=0;"))
        back = HEAD_L - HEAD_OVERLAP
        return (round(tip[0] - ux * back, 2), round(tip[1] - uy * back, 2))

    def _terminal(self, p):
        for b in self.blocks + self.ops:
            x0, y0, x1, y1 = b["x"], b["y"], b["x"] + b["w"], b["y"] + b["h"]
            on_v = (abs(p[0] - x0) < 0.02 or abs(p[0] - x1) < 0.02) and y0 - 0.02 <= p[1] <= y1 + 0.02
            on_h = (abs(p[1] - y0) < 0.02 or abs(p[1] - y1) < 0.02) and x0 - 0.02 <= p[0] <= x1 + 0.02
            if on_v or on_h:
                return b
        return None

    def legend(self, x, y, items, gap=12, fs=FS_N):
        """A one-line legend: items are (kind, text)."""
        for kind, label in items:
            self.edge([(x, y), (x + 22, y)], kind=kind, attach=False)
            w = measure(label, fs)[0]
            self.text(x + 27, y - 7, w + 2, 14, label, fs=fs, align="left")
            x += 27 + w + gap
        return x

    # -------------------------------------------------------------------- checks
    def check(self):
        issues = list(self.issues)
        boxes = self.blocks + self.ops
        for c in self.cards + boxes + self.icons:
            if c["x"] < -0.7 or c["y"] < -0.7 or c["x"] + c["w"] > self.W + 0.7 or c["y"] + c["h"] > self.H + 0.7:
                issues.append(f"{c['id']} lies outside the figure")
        ext = [c["x"] - SW_CARD / 2 for c in self.cards + boxes] + [l[0] for l in self.labels] + [p[0] for e in self.lines for p in e["pts"]]
        ext_r = [c["x"] + c["w"] + SW_CARD / 2 for c in self.cards + boxes] + [l[2] for l in self.labels] + [p[0] for e in self.lines for p in e["pts"]]
        if abs(min(ext)) > 0.6 or abs(max(ext_r) - self.W) > 0.6:
            issues.append(f"content spans {min(ext):.1f} .. {max(ext_r):.1f}, not the full width 0 .. {self.W:.1f}")
        for e in self.lines:
            ends = {id(t) for t in (e["src"], e["dst"]) if t}
            for (xa, ya), (xb, yb) in zip(e["pts"], e["pts"][1:]):
                sx0, sx1, sy0, sy1 = min(xa, xb), max(xa, xb), min(ya, yb), max(ya, yb)
                for (lx0, ly0, lx1, ly1, owner, what) in self.labels:
                    if sx0 < lx1 + 0.8 and sx1 > lx0 - 0.8 and sy0 < ly1 - 1.0 and sy1 > ly0 + 1.0:
                        issues.append(f"connector {e['id']} runs over text {re.sub('<[^>]+>', ' ', what)[:40]!r}")
                for b in boxes + self.icons:
                    if id(b) in ends:
                        continue
                    if sx0 < b["x"] + b["w"] - 0.5 and sx1 > b["x"] + 0.5 and sy0 < b["y"] + b["h"] - 0.5 and sy1 > b["y"] + 0.5:
                        issues.append(f"connector {e['id']} passes through {b['id']} ({re.sub('<[^>]+>', ' ', b['value'])[:30]!r})")
        for i, (ax0, ay0, ax1, ay1, ao, aw) in enumerate(self.labels):
            for (bx0, by0, bx1, by1, bo, bw) in self.labels[i + 1:]:
                if ax0 < bx1 - 0.5 and ax1 > bx0 + 0.5 and ay0 < by1 - 1.5 and ay1 > by0 + 1.5:
                    issues.append(f"texts overlap: {re.sub('<[^>]+>', ' ', aw)[:30]!r} and {re.sub('<[^>]+>', ' ', bw)[:30]!r}")
            for ic in self.icons:
                if ax0 < ic["x"] + ic["w"] - 0.5 and ax1 > ic["x"] + 0.5 and ay0 < ic["y"] + ic["h"] - 1 and ay1 > ic["y"] + 1:
                    issues.append(f"text overlaps an icon: {re.sub('<[^>]+>', ' ', aw)[:30]!r}")
        colours = set(re.findall(r"#[0-9A-Fa-f]{6}", " ".join(c["style"] for c in self.cards + boxes + self.texts + self.lines)))
        for col in colours - PALETTE:
            issues.append(f"colour outside the palette: {col}")
        return issues

    # ------------------------------------------------------------------ emission
    def _parent(self, c):
        best = None
        for k in self.cards:
            if k is c:
                continue
            if k["x"] - 0.01 <= c["x"] and k["y"] - 0.01 <= c["y"] and c["x"] + c["w"] <= k["x"] + k["w"] + 0.01 and c["y"] + c["h"] <= k["y"] + k["h"] + 0.01:
                if best is None or k["w"] * k["h"] < best["w"] * best["h"]:
                    best = k
        return best

    def xml(self):
        out = []
        for c in self.cards + self.blocks + self.ops + self.icons + self.texts:
            par = self._parent(c)
            px, py, pid = (par["x"], par["y"], par["id"]) if par else (0, 0, "1")
            out.append(f'<mxCell id="{c["id"]}" value="{_esc(c["value"])}" style="{c["style"]}" vertex="1" parent="{pid}">'
                       f'<mxGeometry x="{_n(c["x"] - px)}" y="{_n(c["y"] - py)}" width="{_n(c["w"])}" height="{_n(c["h"])}" as="geometry"/></mxCell>')
        for hd in self.heads:
            par = hd["owner"] or self._parent(hd)
            px, py, pid = (par["x"], par["y"], par["id"]) if par else (0, 0, "1")
            out.append(f'<mxCell id="{hd["id"]}" value="" style="{hd["style"]}" vertex="1" parent="{pid}">'
                       f'<mxGeometry x="{_n(hd["x"] - px)}" y="{_n(hd["y"] - py)}" width="{_n(hd["w"])}" height="{_n(hd["h"])}" as="geometry"/></mxCell>')
        for e in self.lines:
            pts, style, attrs, ends = e["draw"], e["style"], "", ""
            for which, term, p in (("exit", e["src"], pts[0]), ("entry", e["dst"], pts[-1])):
                role = "source" if which == "exit" else "target"
                if term:
                    attrs += f' {role}="{term["id"]}"'
                    style += f"{which}X=0;{which}Y=0;{which}Dx={_n(p[0] - term['x'])};{which}Dy={_n(p[1] - term['y'])};{which}Perimeter=0;"
                else:
                    ends += f'<mxPoint x="{_n(p[0])}" y="{_n(p[1])}" as="{role}Point"/>'
            way = "".join(f'<mxPoint x="{_n(x)}" y="{_n(y)}"/>' for x, y in pts[1:-1])
            out.append(f'<mxCell id="{e["id"]}" style="{style}" edge="1" parent="1"{attrs}><mxGeometry relative="1" as="geometry">'
                       f'{ends}{"<Array as=" + chr(34) + "points" + chr(34) + ">" + way + "</Array>" if way else ""}</mxGeometry></mxCell>')
        return ('<mxfile host="kyber6g-figlib" type="device"><diagram id="' + self.name + '" name="' + self.name + '">'
                f'<mxGraphModel dx="0" dy="0" grid="0" gridSize="1" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="0" '
                f'pageScale="1" pageWidth="{_n(self.W)}" pageHeight="{_n(self.H)}" math="0" shadow="0">'
                '<root><mxCell id="0"/><mxCell id="1" parent="0"/>' + "".join(out) + "</root></mxGraphModel></diagram></mxfile>\n")

    def save(self, directory=None):
        directory = Path(directory or ROOT / "raw_drawio")
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"{self.name}.drawio"
        path.write_text(self.xml())
        return path
