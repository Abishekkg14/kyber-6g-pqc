# Build report

Built 2026-10-04 02:43 with draw.io Desktop 31.7.0, pdfcrop, Ghostscript 9.55.0 and poppler. Every value below was measured on the produced files.

| Figure | Width × height (mm) | Text sizes (pt) | Fonts embedded | Raster images | Connectors drawn as designed | Layout problems |
|---|---|---|---|---|---|---|
| fig01_system_architecture | 190.00 × 86.91 | 7, 8, 9 | Arial-BoldMT, ArialMT | 0 | 26 of 26 | none |
| fig02_threat_model | 90.00 × 96.30 | 7, 8, 9 | Arial-BoldMT, ArialMT | 0 | 8 of 8 | none |
| fig03_handshake | 190.00 × 94.37 | 6.5, 7, 8, 9 | Arial-BoldMT, Arial-ItalicMT, ArialMT | 0 | 4 of 4 | none |
| fig04_key_schedule | 90.00 × 94.19 | 6.5, 7, 8 | Arial-BoldMT, Arial-ItalicMT, ArialMT | 0 | 16 of 16 | none |
| fig05_session_lifecycle | 190.00 × 69.32 | 6.5, 7, 8, 9 | Arial-BoldMT, ArialMT | 0 | 38 of 38 | none |
| fig06_record_layer | 90.00 × 82.28 | 6.5, 7, 8, 9 | Arial-BoldMT, Arial-ItalicMT, ArialMT | 0 | 15 of 15 | none |
| fig07_video_pipeline | 190.00 × 68.27 | 7, 8, 9 | Arial-BoldMT, ArialMT | 0 | 9 of 9 | none |
| fig08_perception_hitl | 190.00 × 66.68 | 7, 8, 9 | Arial-BoldMT, ArialMT | 0 | 12 of 12 | none |
| fig09_recording_at_rest | 90.00 × 88.90 | 6.5, 7, 8, 9 | Arial-BoldMT, Arial-ItalicMT, ArialMT | 0 | 12 of 12 | none |
| fig10_evaluation_workflow | 190.00 × 61.24 | 7, 8, 9 | Arial-BoldMT, ArialMT | 0 | 11 of 11 | none |
