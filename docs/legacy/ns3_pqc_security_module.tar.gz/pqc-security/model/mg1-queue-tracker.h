/* -*- Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */

// Copyright (c) 2026 Kyber-6G Project
// SPDX-License-Identifier: GPL-2.0-only

#ifndef MG1_QUEUE_TRACKER_H
#define MG1_QUEUE_TRACKER_H

#include "ns3/nstime.h"
#include "ns3/object.h"
#include "ns3/traced-callback.h"
#include "ns3/type-id.h"

#include <cmath>
#include <cstdint>

namespace ns3
{
namespace pqc
{

/**
 * \brief M/G/1 queue tracker using Welford's online algorithm.
 *
 * Replaces the implicit M/M/1 queue assumption with an explicit M/G/1 model
 * that tracks the first and second moments of general service times using
 * Welford's numerically stable online algorithm (no memory bloat).
 *
 * The Pollaczek-Khinchine mean value formula is computed in real-time:
 *   W_q = lambda * E[S^2] / (2 * (1 - rho))
 *
 * Key features:
 * - O(1) memory: only running mean, M2, count, and arrival rate
 * - Numerically stable: Welford's avoids catastrophic cancellation
 * - TCP RTO cascade detection: flags when W_q exceeds configurable threshold
 * - Trace source integration with PqcMetricsCollector
 *
 * Reference:
 *   B.P. Welford, "Note on a Method for Calculating Corrected Sums of
 *   Squares and Products," Technometrics, vol. 4, no. 3, 1962.
 *   F. Pollaczek, "Uber eine Aufgabe der Wahrscheinlichkeitstheorie," 1930.
 */
class Mg1QueueTracker : public Object
{
  public:
    static TypeId GetTypeId();

    Mg1QueueTracker();
    ~Mg1QueueTracker() override;

    // ═══════════════════════════════════════════════════
    // Service time recording (Welford's online algorithm)
    // ═══════════════════════════════════════════════════

    /**
     * \brief Record a service time sample.
     *
     * Updates E[S] and E[S^2] using Welford's numerically stable
     * one-pass algorithm. O(1) time and memory per call.
     *
     * \param serviceTime The observed service time for one PQC handshake/packet
     */
    void RecordServiceTime(Time serviceTime);

    /**
     * \brief Record an arrival event (for lambda estimation).
     *
     * Call this each time a new handshake request arrives at the gateway.
     * The arrival rate is estimated as count / elapsed_time.
     */
    void RecordArrival();

    // ═══════════════════════════════════════════════════
    // M/G/1 Pollaczek-Khinchine computations
    // ═══════════════════════════════════════════════════

    /**
     * \brief Get the current estimate of E[S] (mean service time) in seconds.
     */
    double GetMeanServiceTimeS() const;

    /**
     * \brief Get the current estimate of E[S^2] (second moment) in seconds^2.
     *
     * E[S^2] = Var(S) + (E[S])^2, computed from Welford's running stats.
     */
    double GetSecondMomentS2() const;

    /**
     * \brief Get the variance of service time Var(S) in seconds^2.
     */
    double GetVarianceS2() const;

    /**
     * \brief Get the coefficient of variation C_S^2 = Var(S) / (E[S])^2.
     *
     * For M/M/1: C_S^2 = 1 (exponential).
     * For bimodal PQC traffic (cache hit/miss): C_S^2 can be >> 1 or << 1.
     * The M/G/1 correction factor is (1 + C_S^2) / 2.
     */
    double GetCoefficientOfVariationSquared() const;

    /**
     * \brief Get the estimated arrival rate lambda (arrivals/second).
     */
    double GetArrivalRateLambda() const;

    /**
     * \brief Get the server utilization rho = lambda * E[S].
     */
    double GetUtilization() const;

    /**
     * \brief Compute the P-K mean waiting time W_q = lambda * E[S^2] / (2 * (1 - rho)).
     *
     * Returns Time::Max() if the queue is unstable (rho >= 1).
     *
     * \return Mean waiting time as ns3::Time
     */
    Time GetPollaczekKhinchineMeanWait() const;

    /**
     * \brief Get the M/G/1 to M/M/1 correction ratio: (1 + C_S^2) / 2.
     *
     * If > 1: M/G/1 predicts higher delays than M/M/1 (high service variance).
     * If < 1: M/G/1 predicts lower delays (low service variance, e.g., deterministic).
     * If = 1: Service is exponential, M/G/1 reduces to M/M/1.
     */
    double GetMg1CorrectionFactor() const;

    /**
     * \brief Check if the queue is in a TCP RTO cascade condition.
     *
     * Returns true if W_q > rtoThreshold.
     *
     * \param rtoThreshold The RTO threshold (default: 200ms)
     * \return true if cascade condition detected
     */
    bool IsTcpRtoCascade(Time rtoThreshold = MilliSeconds(200)) const;

    /**
     * \brief Get the number of service time samples recorded.
     */
    uint64_t GetSampleCount() const;

    /**
     * \brief Reset all statistics.
     */
    void Reset();

    // ═══════════════════════════════════════════════════
    // Trace sources
    // ═══════════════════════════════════════════════════

    TracedCallback<double> m_meanWaitTrace;         ///< Fires with W_q in microseconds
    TracedCallback<double> m_utilizationTrace;       ///< Fires with rho
    TracedCallback<double> m_secondMomentTrace;      ///< Fires with E[S^2] in us^2
    TracedCallback<bool>   m_rtoCascadeTrace;        ///< Fires when cascade detected/cleared

  private:
    // ── Welford's online statistics ──
    uint64_t m_count{0};       ///< Number of service time samples
    double   m_mean{0.0};      ///< Running mean E[S] in seconds
    double   m_m2{0.0};        ///< Running sum of squared deviations (Welford's M2)

    // ── Arrival rate estimation ──
    uint64_t m_arrivalCount{0};  ///< Number of arrivals
    Time     m_firstArrival;     ///< Time of first recorded arrival
    Time     m_lastArrival;      ///< Time of most recent arrival

    // ── Configuration ──
    Time     m_rtoThreshold{MilliSeconds(200)}; ///< TCP RTO cascade threshold
    bool     m_cascadeActive{false};             ///< Current cascade state
};

} // namespace pqc
} // namespace ns3

#endif // MG1_QUEUE_TRACKER_H
