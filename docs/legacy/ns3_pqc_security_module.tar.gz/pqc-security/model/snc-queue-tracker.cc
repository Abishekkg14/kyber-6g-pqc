/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
// Copyright (c) 2026 Kyber-6G Project
// SPDX-License-Identifier: GPL-2.0-only

#include "snc-queue-tracker.h"
#include "ns3/log.h"
#include <cmath>
#include <algorithm>

namespace ns3 {
namespace pqc {

NS_LOG_COMPONENT_DEFINE("SncQueueTracker");

NS_OBJECT_ENSURE_REGISTERED(SncQueueTracker);

TypeId
SncQueueTracker::GetTypeId(void)
{
    static TypeId tid = TypeId("ns3::pqc::SncQueueTracker")
        .SetParent<Object>()
        .SetGroupName("PqcSecurity")
        .AddConstructor<SncQueueTracker>();
    return tid;
}

SncQueueTracker::SncQueueTracker()
{
}

SncQueueTracker::~SncQueueTracker()
{
}

void
SncQueueTracker::RecordArrival(Time arrivalTime)
{
    m_arrivalTimes.push_back(arrivalTime);
}

void
SncQueueTracker::RecordServiceTime(Time serviceTime)
{
    m_serviceTimes.push_back(serviceTime);
}

Time
SncQueueTracker::ComputeProbabilisticDelayBound(double epsilon) const
{
    if (m_serviceTimes.empty()) {
        return Seconds(0);
    }
    
    // Empirical estimation of mean service time
    double sumServiceUs = 0.0;
    for (const auto& st : m_serviceTimes) {
        sumServiceUs += st.GetMicroSeconds();
    }
    double mu_service = sumServiceUs / m_serviceTimes.size();
    
    // Using a simplified SNC MGF-based bound for a G/G/1 like system
    // where P(Delay > D) <= exp(-theta * (C * D - sigma))
    // Here we invert the bound: D_max = (-ln(epsilon) / theta + sigma) / C
    // We calibrate constants based on empirical service times to provide a 
    // theoretical latency bound mapping.
    
    double theta = 0.05; // Chernoff bound optimization parameter (simplified)
    double capacity = 1000000.0 / mu_service; // packets per second roughly
    double D_max_sec = (-std::log(epsilon)) / (theta * capacity);
    
    NS_LOG_INFO("SNC Probabilistic Bound for epsilon=" << epsilon << " is " << D_max_sec * 1000.0 << " ms");
    return MicroSeconds(static_cast<int64_t>(D_max_sec * 1e6));
}

} // namespace pqc
} // namespace ns3
