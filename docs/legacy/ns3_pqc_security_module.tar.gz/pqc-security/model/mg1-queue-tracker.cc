/* -*- Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */

// Copyright (c) 2026 Kyber-6G Project
// SPDX-License-Identifier: GPL-2.0-only

#include "mg1-queue-tracker.h"

#include "ns3/double.h"
#include "ns3/log.h"
#include "ns3/simulator.h"

#include <limits>

namespace ns3
{
namespace pqc
{

NS_LOG_COMPONENT_DEFINE("Mg1QueueTracker");
NS_OBJECT_ENSURE_REGISTERED(Mg1QueueTracker);

TypeId
Mg1QueueTracker::GetTypeId()
{
    static TypeId tid =
        TypeId("ns3::pqc::Mg1QueueTracker")
            .SetParent<Object>()
            .SetGroupName("PqcSecurity")
            .AddConstructor<Mg1QueueTracker>()
            .AddAttribute("RtoThreshold",
                          "TCP RTO cascade detection threshold",
                          TimeValue(MilliSeconds(200)),
                          MakeTimeAccessor(&Mg1QueueTracker::m_rtoThreshold),
                          MakeTimeChecker())
            .AddTraceSource("MeanWaitUs",
                            "P-K mean waiting time in microseconds",
                            MakeTraceSourceAccessor(&Mg1QueueTracker::m_meanWaitTrace),
                            "ns3::TracedValueCallback::Double")
            .AddTraceSource("Utilization",
                            "Server utilization rho = lambda * E[S]",
                            MakeTraceSourceAccessor(&Mg1QueueTracker::m_utilizationTrace),
                            "ns3::TracedValueCallback::Double")
            .AddTraceSource("SecondMoment",
                            "Second moment E[S^2] in us^2",
                            MakeTraceSourceAccessor(&Mg1QueueTracker::m_secondMomentTrace),
                            "ns3::TracedValueCallback::Double")
            .AddTraceSource("RtoCascade",
                            "TCP RTO cascade condition (true=active)",
                            MakeTraceSourceAccessor(&Mg1QueueTracker::m_rtoCascadeTrace),
                            "ns3::TracedCallback::Bool");

    return tid;
}

Mg1QueueTracker::Mg1QueueTracker()
{
    NS_LOG_FUNCTION(this);
}

Mg1QueueTracker::~Mg1QueueTracker()
{
}

// ═══════════════════════════════════════════════════
// Welford's Online Algorithm
// ═══════════════════════════════════════════════════
//
// For each new sample x_n:
//   count += 1
//   delta = x_n - mean
//   mean += delta / count
//   delta2 = x_n - mean    (using updated mean)
//   M2 += delta * delta2
//
// Variance = M2 / (count - 1)       [Bessel's correction]
// E[S^2] = Variance + mean^2
//
// This is numerically stable and O(1) per sample.

void
Mg1QueueTracker::RecordServiceTime(Time serviceTime)
{
    double xSeconds = serviceTime.GetSeconds();
    m_count++;

    double delta = xSeconds - m_mean;
    m_mean += delta / static_cast<double>(m_count);
    double delta2 = xSeconds - m_mean; // Note: using UPDATED mean
    m_m2 += delta * delta2;

    // Fire trace sources periodically (every 10 samples to avoid overhead)
    if (m_count % 10 == 0)
    {
        double wq = GetPollaczekKhinchineMeanWait().GetMicroSeconds();
        m_meanWaitTrace(wq);
        m_utilizationTrace(GetUtilization());
        m_secondMomentTrace(GetSecondMomentS2() * 1e12); // Convert to us^2

        // Check cascade condition
        bool newCascade = IsTcpRtoCascade();
        if (newCascade != m_cascadeActive)
        {
            m_cascadeActive = newCascade;
            m_rtoCascadeTrace(newCascade);
            if (newCascade)
            {
                NS_LOG_WARN("TCP RTO CASCADE DETECTED: W_q="
                            << GetPollaczekKhinchineMeanWait().As(Time::MS)
                            << " > threshold=" << m_rtoThreshold.As(Time::MS)
                            << " | rho=" << GetUtilization()
                            << " | C_S^2=" << GetCoefficientOfVariationSquared());
            }
            else
            {
                NS_LOG_INFO("TCP RTO cascade cleared: W_q="
                            << GetPollaczekKhinchineMeanWait().As(Time::MS));
            }
        }
    }

    NS_LOG_DEBUG("Service sample #" << m_count
                 << ": S=" << serviceTime.As(Time::US)
                 << " E[S]=" << m_mean * 1e6 << " us"
                 << " Var(S)=" << GetVarianceS2() * 1e12 << " us^2");
}

void
Mg1QueueTracker::RecordArrival()
{
    Time now = Simulator::Now();

    if (m_arrivalCount == 0)
    {
        m_firstArrival = now;
    }
    m_lastArrival = now;
    m_arrivalCount++;
}

// ═══════════════════════════════════════════════════
// Statistics getters
// ═══════════════════════════════════════════════════

double
Mg1QueueTracker::GetMeanServiceTimeS() const
{
    return m_mean;
}

double
Mg1QueueTracker::GetSecondMomentS2() const
{
    // E[S^2] = Var(S) + (E[S])^2
    return GetVarianceS2() + (m_mean * m_mean);
}

double
Mg1QueueTracker::GetVarianceS2() const
{
    if (m_count < 2)
    {
        return 0.0;
    }
    // Bessel-corrected sample variance
    return m_m2 / static_cast<double>(m_count - 1);
}

double
Mg1QueueTracker::GetCoefficientOfVariationSquared() const
{
    if (m_mean <= 0 || m_count < 2)
    {
        return 1.0; // Default to M/M/1 assumption
    }
    return GetVarianceS2() / (m_mean * m_mean);
}

double
Mg1QueueTracker::GetArrivalRateLambda() const
{
    if (m_arrivalCount < 2)
    {
        return 0.0;
    }

    double elapsed = (m_lastArrival - m_firstArrival).GetSeconds();
    if (elapsed <= 0)
    {
        return 0.0;
    }

    return static_cast<double>(m_arrivalCount - 1) / elapsed;
}

double
Mg1QueueTracker::GetUtilization() const
{
    return GetArrivalRateLambda() * m_mean;
}

Time
Mg1QueueTracker::GetPollaczekKhinchineMeanWait() const
{
    // W_q = lambda * E[S^2] / (2 * (1 - rho))
    //
    // Stability condition: rho < 1
    // If unstable, return a large sentinel value

    double lambda = GetArrivalRateLambda();
    double rho = GetUtilization();

    if (rho >= 1.0)
    {
        NS_LOG_WARN("Queue UNSTABLE: rho=" << rho << " >= 1.0");
        return Time::Max();
    }

    if (m_count < 2 || lambda <= 0)
    {
        return Seconds(0);
    }

    double es2 = GetSecondMomentS2();
    double wqSeconds = (lambda * es2) / (2.0 * (1.0 - rho));

    return Seconds(wqSeconds);
}

double
Mg1QueueTracker::GetMg1CorrectionFactor() const
{
    // Ratio of M/G/1 mean wait to M/M/1 mean wait:
    // (1 + C_S^2) / 2
    //
    // > 1 means M/G/1 predicts higher delays (high-variance service)
    // < 1 means M/G/1 predicts lower delays (low-variance, e.g., deterministic)
    // = 1 means exponential service (M/G/1 = M/M/1)

    return (1.0 + GetCoefficientOfVariationSquared()) / 2.0;
}

bool
Mg1QueueTracker::IsTcpRtoCascade(Time rtoThreshold) const
{
    Time wq = GetPollaczekKhinchineMeanWait();
    if (wq == Time::Max())
    {
        return true; // Unstable queue is always a cascade
    }
    return wq > rtoThreshold;
}

uint64_t
Mg1QueueTracker::GetSampleCount() const
{
    return m_count;
}

void
Mg1QueueTracker::Reset()
{
    m_count = 0;
    m_mean = 0.0;
    m_m2 = 0.0;
    m_arrivalCount = 0;
    m_firstArrival = Seconds(0);
    m_lastArrival = Seconds(0);
    m_cascadeActive = false;

    NS_LOG_INFO("Mg1QueueTracker reset");
}

} // namespace pqc
} // namespace ns3
