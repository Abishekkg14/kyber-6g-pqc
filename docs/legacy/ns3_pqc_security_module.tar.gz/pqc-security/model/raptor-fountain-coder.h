/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
// Copyright (c) 2026 Kyber-6G Project
// SPDX-License-Identifier: GPL-2.0-only

#ifndef RAPTOR_FOUNTAIN_CODER_H
#define RAPTOR_FOUNTAIN_CODER_H

#include "ns3/object.h"
#include "ns3/packet.h"
#include <vector>
#include <map>
#include <stdint.h>

namespace ns3 {
namespace pqc {

/**
 * \brief Application-layer Rateless Raptor (Fountain) Coder.
 * 
 * Implements fountain coding to fragment and reassemble large PQC payloads
 * (e.g. ML-KEM/ML-DSA encapsulations) over lossy THz channels, mitigating
 * TCP Head-of-Line blocking and RTO cascades.
 */
class RaptorFountainCoder : public Object
{
public:
    static TypeId GetTypeId(void);
    RaptorFountainCoder();
    virtual ~RaptorFountainCoder();

    /**
     * \brief Encode a payload into multiple Raptor symbols.
     * \param payload The full payload to encode.
     * \param symbolSize The size of each symbol in bytes.
     * \param overheadRatio The redundant overhead (e.g., 1.05 for 5% overhead).
     * \return Vector of encoded symbol packets.
     */
    std::vector<Ptr<Packet>> Encode(Ptr<Packet> payload, uint32_t symbolSize, double overheadRatio = 1.10);

    /**
     * \brief Receive and attempt to decode a Raptor symbol.
     * \param symbolId The unique ID of the original payload this symbol belongs to.
     * \param symbol The symbol packet.
     * \param totalSourceSymbols The number of source symbols required to decode.
     * \return A decoded payload Packet if successful, or nullptr if more symbols are needed.
     */
    Ptr<Packet> ReceiveSymbol(uint64_t symbolId, Ptr<Packet> symbol, uint32_t totalSourceSymbols);

private:
    struct DecodingState {
        uint32_t receivedSymbols;
        uint32_t requiredSymbols;
        uint32_t totalSize;
        std::vector<Ptr<Packet>> symbolBuffer;
    };
    
    std::map<uint64_t, DecodingState> m_decodingStates;
};

} // namespace pqc
} // namespace ns3

#endif /* RAPTOR_FOUNTAIN_CODER_H */
