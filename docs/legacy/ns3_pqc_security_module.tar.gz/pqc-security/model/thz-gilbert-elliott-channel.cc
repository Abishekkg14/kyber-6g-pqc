/* -*- Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */

// Copyright (c) 2026 Kyber-6G Project
// SPDX-License-Identifier: GPL-2.0-only

#include "thz-gilbert-elliott-channel.h"

#include "ns3/double.h"
#include "ns3/log.h"
#include "ns3/simulator.h"
#include "ns3/uinteger.h"

#include <cmath>

namespace ns3
{
namespace pqc
{

NS_LOG_COMPONENT_DEFINE("ThzGilbertElliottChannel");
NS_OBJECT_ENSURE_REGISTERED(ThzGilbertElliottChannel);

TypeId
ThzGilbertElliottChannel::GetTypeId()
{
    static TypeId tid =
        TypeId("ns3::pqc::ThzGilbertElliottChannel")
            .SetParent<Object>()
            .SetGroupName("PqcSecurity")
            .AddConstructor<ThzGilbertElliottChannel>()
            .AddAttribute("CarrierFrequencyHz",
                          "Carrier frequency in Hz (default 140 GHz for THz band)",
                          DoubleValue(140e9),
                          MakeDoubleAccessor(&ThzGilbertElliottChannel::m_carrierFreqHz),
                          MakeDoubleChecker<double>(1e9, 1e13))
            .AddAttribute("VelocityMs",
                          "UE velocity in m/s (default 120 for high-speed UAV)",
                          DoubleValue(120.0),
                          MakeDoubleAccessor(&ThzGilbertElliottChannel::m_velocityMs),
                          MakeDoubleChecker<double>(0.1, 1000.0))
            .AddAttribute("GoodStateErrorRate",
                          "Packet error rate in Good state (default 1e-4)",
                          DoubleValue(1e-4),
                          MakeDoubleAccessor(&ThzGilbertElliottChannel::m_epsilonG),
                          MakeDoubleChecker<double>(0.0, 1.0))
            .AddAttribute("BadStateErrorRate",
                          "Packet error rate in Bad state (default 0.3)",
                          DoubleValue(0.3),
                          MakeDoubleAccessor(&ThzGilbertElliottChannel::m_epsilonB),
                          MakeDoubleChecker<double>(0.0, 1.0))
            .AddAttribute("TransitionProbGB",
                          "Transition probability Good -> Bad per coherence interval",
                          DoubleValue(0.05),
                          MakeDoubleAccessor(&ThzGilbertElliottChannel::m_pGB),
                          MakeDoubleChecker<double>(0.0, 1.0))
            .AddAttribute("TransitionProbBG",
                          "Transition probability Bad -> Good per coherence interval",
                          DoubleValue(0.3),
                          MakeDoubleAccessor(&ThzGilbertElliottChannel::m_pBG),
                          MakeDoubleChecker<double>(0.0, 1.0))
            .AddTraceSource("StateChange",
                            "Channel state transition (0=Good, 1=Bad)",
                            MakeTraceSourceAccessor(&ThzGilbertElliottChannel::m_stateChangeTrace),
                            "ns3::TracedValueCallback::Uint8")
            .AddTraceSource("PdrComputed",
                            "PDR computed for a fragmented transmission",
                            MakeTraceSourceAccessor(&ThzGilbertElliottChannel::m_pdrTrace),
                            "ns3::TracedValueCallback::Double")
            .AddTraceSource("FragmentDelivery",
                            "Per-fragment delivery result (true=success)",
                            MakeTraceSourceAccessor(&ThzGilbertElliottChannel::m_fragmentDeliveryTrace),
                            "ns3::TracedCallback::Bool");

    return tid;
}

ThzGilbertElliottChannel::ThzGilbertElliottChannel()
    : m_currentState(State::GOOD)
{
    m_rng = CreateObject<UniformRandomVariable>();
    m_rng->SetAttribute("Min", DoubleValue(0.0));
    m_rng->SetAttribute("Max", DoubleValue(1.0));

    NS_LOG_INFO("ThzGilbertElliottChannel created: f_c="
                << m_carrierFreqHz / 1e9 << " GHz, v=" << m_velocityMs
                << " m/s, T_c=" << GetCoherenceTimeS() * 1e6 << " us");
}

ThzGilbertElliottChannel::~ThzGilbertElliottChannel()
{
}

// ═══════════════════════════════════════════════════
// Configuration setters
// ═══════════════════════════════════════════════════

void
ThzGilbertElliottChannel::SetCarrierFrequencyHz(double freqHz)
{
    m_carrierFreqHz = freqHz;
}

void
ThzGilbertElliottChannel::SetVelocityMs(double velocity)
{
    m_velocityMs = velocity;
}

void
ThzGilbertElliottChannel::SetGoodStateErrorRate(double epsilonG)
{
    m_epsilonG = epsilonG;
}

void
ThzGilbertElliottChannel::SetBadStateErrorRate(double epsilonB)
{
    m_epsilonB = epsilonB;
}

void
ThzGilbertElliottChannel::SetTransitionProbGB(double pGB)
{
    m_pGB = pGB;
}

void
ThzGilbertElliottChannel::SetTransitionProbBG(double pBG)
{
    m_pBG = pBG;
}

// ═══════════════════════════════════════════════════
// Analytical computations
// ═══════════════════════════════════════════════════

double
ThzGilbertElliottChannel::GetCoherenceTimeS() const
{
    // T_c = c / (f_c * v)
    // At 140 GHz, 120 m/s: T_c = 3e8 / (140e9 * 120) = 17.86 us
    if (m_carrierFreqHz <= 0 || m_velocityMs <= 0)
    {
        return 1.0; // Fallback to 1 second for static scenario
    }
    return SPEED_OF_LIGHT / (m_carrierFreqHz * m_velocityMs);
}

double
ThzGilbertElliottChannel::GetSteadyStateProbGood() const
{
    double denom = m_pGB + m_pBG;
    if (denom <= 0)
    {
        return 1.0; // All-good channel if no transitions
    }
    return m_pBG / denom;
}

double
ThzGilbertElliottChannel::GetSteadyStateProbBad() const
{
    return 1.0 - GetSteadyStateProbGood();
}

double
ThzGilbertElliottChannel::ComputePdr(uint32_t numFragments) const
{
    // PDR(n) = pi_G * (1 - epsilon_G)^n + pi_B * (1 - epsilon_B)^n
    //
    // This formula gives the probability that ALL n fragments are delivered
    // successfully, averaged over the steady-state channel distribution.
    //
    // Key insight: for n > 1, the exponential decay in the Bad state
    // dominates, causing catastrophic PDR collapse for fragmented PQC payloads.

    double piG = GetSteadyStateProbGood();
    double piB = GetSteadyStateProbBad();
    double n = static_cast<double>(numFragments);

    double pdrGood = std::pow(1.0 - m_epsilonG, n);
    double pdrBad  = std::pow(1.0 - m_epsilonB, n);

    double pdr = piG * pdrGood + piB * pdrBad;

    NS_LOG_DEBUG("PDR(n=" << numFragments << "): piG=" << piG
                 << " piB=" << piB << " pdrG=" << pdrGood
                 << " pdrB=" << pdrBad << " -> PDR=" << pdr);

    return pdr;
}

double
ThzGilbertElliottChannel::ComputeTcpRtoCascadeProbability(uint32_t numFragments,
                                                           uint32_t consecutiveFailures) const
{
    // A TCP RTO cascade occurs when >= consecutiveFailures consecutive
    // retransmissions fail. Each retransmission attempt fails independently
    // with probability (1 - PDR(n)).
    //
    // P(cascade) = (1 - PDR(n))^consecutiveFailures
    //
    // With exponential backoff, the total delay is:
    //   T_cascade = sum_{k=0}^{F-1} min(2^k * RTO_0, 60s)
    //
    // For RTO_0 = 200ms and F = 3: T_cascade >= 200 + 400 + 800 = 1400 ms
    // This exceeds the THz beam coherence window by ~78,600x, causing
    // the UAV to fly outside its MIMO beamforming envelope.

    double pdr = ComputePdr(numFragments);
    double pFail = 1.0 - pdr;
    double pCascade = std::pow(pFail, static_cast<double>(consecutiveFailures));

    NS_LOG_DEBUG("TCP RTO cascade P(F>=" << consecutiveFailures
                 << " | n=" << numFragments << "): pFail=" << pFail
                 << " -> P(cascade)=" << pCascade);

    return pCascade;
}

// ═══════════════════════════════════════════════════
// Simulation-mode stateful channel
// ═══════════════════════════════════════════════════

void
ThzGilbertElliottChannel::StepChannel()
{
    double u = m_rng->GetValue();
    State prevState = m_currentState;

    if (m_currentState == State::GOOD)
    {
        if (u < m_pGB)
        {
            m_currentState = State::BAD;
        }
    }
    else // BAD
    {
        if (u < m_pBG)
        {
            m_currentState = State::GOOD;
        }
    }

    if (m_currentState != prevState)
    {
        m_stateChangeTrace(static_cast<uint8_t>(m_currentState));
        NS_LOG_DEBUG("Channel state: " << (prevState == State::GOOD ? "G" : "B")
                     << " -> " << (m_currentState == State::GOOD ? "G" : "B")
                     << " at t=" << Simulator::Now().As(Time::US));
    }
}

ThzGilbertElliottChannel::State
ThzGilbertElliottChannel::GetCurrentState() const
{
    return m_currentState;
}

bool
ThzGilbertElliottChannel::SimulateFragmentedTransmission(uint32_t numFragments)
{
    // Simulate each fragment independently with the current state's error rate
    double epsilon = (m_currentState == State::GOOD) ? m_epsilonG : m_epsilonB;

    bool allDelivered = true;
    for (uint32_t i = 0; i < numFragments; ++i)
    {
        double u = m_rng->GetValue();
        bool fragmentOk = (u >= epsilon);
        m_fragmentDeliveryTrace(fragmentOk);

        if (!fragmentOk)
        {
            allDelivered = false;
            // Early exit: if any fragment is lost, the entire payload fails
            // (remaining fragments are still transmitted but useless)
            NS_LOG_DEBUG("Fragment " << i << "/" << numFragments
                         << " LOST in state "
                         << (m_currentState == State::GOOD ? "G" : "B"));
            break;
        }
    }

    double computedPdr = ComputePdr(numFragments);
    m_pdrTrace(computedPdr);

    return allDelivered;
}

uint32_t
ThzGilbertElliottChannel::ComputeFragmentCount(uint32_t payloadBytes, uint32_t mtuBytes)
{
    if (mtuBytes == 0)
    {
        return 1;
    }
    // Account for IPv6 header (40B) + UDP header (8B) = 48B overhead per fragment
    // First fragment carries the full headers; subsequent fragments carry
    // the IPv6 fragment extension header (8B)
    constexpr uint32_t IPV6_HEADER = 40;
    constexpr uint32_t UDP_HEADER = 8;
    constexpr uint32_t FRAG_EXT_HEADER = 8;

    uint32_t firstFragPayload = mtuBytes - IPV6_HEADER - UDP_HEADER;
    uint32_t subsequentFragPayload = mtuBytes - IPV6_HEADER - FRAG_EXT_HEADER;

    if (payloadBytes <= firstFragPayload)
    {
        return 1;
    }

    uint32_t remaining = payloadBytes - firstFragPayload;
    uint32_t additionalFrags = (remaining + subsequentFragPayload - 1) / subsequentFragPayload;

    return 1 + additionalFrags;
}

} // namespace pqc
} // namespace ns3
