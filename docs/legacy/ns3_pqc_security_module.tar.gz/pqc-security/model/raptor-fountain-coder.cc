/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
// Copyright (c) 2026 Kyber-6G Project
// SPDX-License-Identifier: GPL-2.0-only

#include "raptor-fountain-coder.h"
#include "ns3/log.h"
#include <cmath>

namespace ns3 {
namespace pqc {

NS_LOG_COMPONENT_DEFINE("RaptorFountainCoder");

NS_OBJECT_ENSURE_REGISTERED(RaptorFountainCoder);

TypeId
RaptorFountainCoder::GetTypeId(void)
{
    static TypeId tid = TypeId("ns3::pqc::RaptorFountainCoder")
        .SetParent<Object>()
        .SetGroupName("PqcSecurity")
        .AddConstructor<RaptorFountainCoder>();
    return tid;
}

RaptorFountainCoder::RaptorFountainCoder()
{
}

RaptorFountainCoder::~RaptorFountainCoder()
{
}

std::vector<Ptr<Packet>>
RaptorFountainCoder::Encode(Ptr<Packet> payload, uint32_t symbolSize, double overheadRatio)
{
    NS_LOG_FUNCTION(this << payload->GetSize() << symbolSize << overheadRatio);
    std::vector<Ptr<Packet>> encodedSymbols;
    
    uint32_t totalSize = payload->GetSize();
    uint32_t k = std::ceil(static_cast<double>(totalSize) / symbolSize);
    uint32_t n = std::ceil(k * overheadRatio); // Total encoded symbols
    
    // Simplification for simulation: We do not perform actual XOR matrix encoding.
    // We just create 'n' packets representing the encoded symbols.
    for (uint32_t i = 0; i < n; ++i)
    {
        uint32_t currentSymbolSize = (i < k && (i == k - 1) && (totalSize % symbolSize != 0)) 
                                     ? (totalSize % symbolSize) : symbolSize;
        Ptr<Packet> sym = Create<Packet>(currentSymbolSize);
        encodedSymbols.push_back(sym);
    }
    
    return encodedSymbols;
}

Ptr<Packet>
RaptorFountainCoder::ReceiveSymbol(uint64_t symbolId, Ptr<Packet> symbol, uint32_t totalSourceSymbols)
{
    NS_LOG_FUNCTION(this << symbolId << symbol->GetSize() << totalSourceSymbols);
    
    if (m_decodingStates.find(symbolId) == m_decodingStates.end())
    {
        DecodingState state;
        state.receivedSymbols = 0;
        state.requiredSymbols = totalSourceSymbols;
        state.totalSize = 0;
        m_decodingStates[symbolId] = state;
    }
    
    auto& state = m_decodingStates[symbolId];
    state.receivedSymbols++;
    state.totalSize += symbol->GetSize();
    state.symbolBuffer.push_back(symbol);
    
    // Raptor decoding property: Can decode if received >= required + small overhead.
    // For simulation, we assume successful decoding once we have requiredSymbols.
    if (state.receivedSymbols >= state.requiredSymbols)
    {
        NS_LOG_INFO("Decoded Raptor payload " << symbolId << " from " << state.receivedSymbols << " symbols");
        Ptr<Packet> decoded = Create<Packet>(state.totalSize);
        m_decodingStates.erase(symbolId);
        return decoded;
    }
    
    return nullptr;
}

} // namespace pqc
} // namespace ns3
