/* -*- Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */

// Copyright (c) 2026 Kyber-6G Project
// SPDX-License-Identifier: GPL-2.0-only

#ifndef THZ_GILBERT_ELLIOTT_CHANNEL_H
#define THZ_GILBERT_ELLIOTT_CHANNEL_H

#include "ns3/object.h"
#include "ns3/nstime.h"
#include "ns3/random-variable-stream.h"
#include "ns3/traced-callback.h"
#include "ns3/type-id.h"

#include <cstdint>

namespace ns3
{
namespace pqc
{

/**
 * \brief Gilbert-Elliott two-state Markov fading model for 140 GHz THz channels.
 *
 * Models bursty packet erasures on THz links with state-dependent error rates.
 * The channel alternates between a "Good" state (low error, line-of-sight dominant)
 * and a "Bad" state (high error, molecular absorption / beam misalignment).
 *
 * State transition rates are derived from the channel coherence time:
 *   T_c = c / (f_c * v) ≈ 17.8 µs  at f_c = 140 GHz, v = 120 m/s
 *
 * For a payload fragmented into n IP packets, the compound PDR is:
 *   PDR(n) = sum_{s in {G,B}} pi_s * (1 - epsilon_s)^n
 *
 * This class does NOT inherit from ns3::Channel; it is a lightweight analytical
 * model attached to the PQC metrics pipeline. For full PHY-layer channel modeling,
 * use the NR module's propagation loss models.
 *
 * Reference: E.N. Gilbert, "Capacity of a Burst-Noise Channel," Bell Syst. Tech. J., 1960.
 */
class ThzGilbertElliottChannel : public Object
{
  public:
    /// Channel state enumeration
    enum class State : uint8_t
    {
        GOOD = 0,
        BAD  = 1
    };

    static TypeId GetTypeId();

    ThzGilbertElliottChannel();
    ~ThzGilbertElliottChannel() override;

    // ═══════════════════════════════════════════════════
    // Configuration
    // ═══════════════════════════════════════════════════

    /**
     * \brief Set the carrier frequency in Hz (default: 140e9 for THz).
     */
    void SetCarrierFrequencyHz(double freqHz);

    /**
     * \brief Set the UE velocity in m/s (default: 120).
     */
    void SetVelocityMs(double velocity);

    /**
     * \brief Set the packet error rate in the Good state (default: 1e-4).
     */
    void SetGoodStateErrorRate(double epsilonG);

    /**
     * \brief Set the packet error rate in the Bad state (default: 0.3).
     */
    void SetBadStateErrorRate(double epsilonB);

    /**
     * \brief Set the transition probability Good -> Bad per coherence interval (default: 0.05).
     */
    void SetTransitionProbGB(double pGB);

    /**
     * \brief Set the transition probability Bad -> Good per coherence interval (default: 0.3).
     */
    void SetTransitionProbBG(double pBG);

    // ═══════════════════════════════════════════════════
    // Analytical computations (no simulation state)
    // ═══════════════════════════════════════════════════

    /**
     * \brief Compute the channel coherence time T_c = c / (f_c * v).
     * \return Coherence time in seconds.
     */
    double GetCoherenceTimeS() const;

    /**
     * \brief Compute the steady-state probability of the Good state.
     * pi_G = p_BG / (p_GB + p_BG)
     */
    double GetSteadyStateProbGood() const;

    /**
     * \brief Compute the steady-state probability of the Bad state.
     * pi_B = p_GB / (p_GB + p_BG)
     */
    double GetSteadyStateProbBad() const;

    /**
     * \brief Compute the PDR for an n-fragment payload.
     * PDR(n) = pi_G * (1 - epsilon_G)^n + pi_B * (1 - epsilon_B)^n
     *
     * \param numFragments Number of IP fragments (1, 2, 3, or 4 typical)
     * \return Packet Delivery Ratio in [0, 1]
     */
    double ComputePdr(uint32_t numFragments) const;

    /**
     * \brief Compute the probability of a TCP RTO cascade (>= consecutiveFailures
     *        consecutive retransmission failures) for an n-fragment payload.
     *
     * P(cascade) = (1 - PDR(n))^consecutiveFailures
     *
     * \param numFragments Number of IP fragments
     * \param consecutiveFailures Threshold for "cascade" (default: 3)
     * \return Probability in [0, 1]
     */
    double ComputeTcpRtoCascadeProbability(uint32_t numFragments,
                                            uint32_t consecutiveFailures = 3) const;

    // ═══════════════════════════════════════════════════
    // Simulation-mode: stateful channel realization
    // ═══════════════════════════════════════════════════

    /**
     * \brief Advance the channel state by one coherence interval.
     * Uses the configured transition probabilities and the NS-3 RNG.
     */
    void StepChannel();

    /**
     * \brief Get the current channel state.
     */
    State GetCurrentState() const;

    /**
     * \brief Simulate transmission of an n-fragment payload through the
     *        current channel state. Returns true if ALL fragments are
     *        successfully delivered.
     *
     * \param numFragments Number of fragments
     * \return true if all fragments delivered, false otherwise
     */
    bool SimulateFragmentedTransmission(uint32_t numFragments);

    /**
     * \brief Compute the number of IP fragments needed for a given payload
     *        size and MTU.
     *
     * n_frag = ceil(payloadBytes / effectiveMtu)
     *
     * \param payloadBytes Total PQC payload size in bytes
     * \param mtuBytes MTU in bytes (default: 1280 for IPv6 minimum)
     * \return Number of fragments
     */
    static uint32_t ComputeFragmentCount(uint32_t payloadBytes, uint32_t mtuBytes = 1280);

    // ═══════════════════════════════════════════════════
    // Trace sources
    // ═══════════════════════════════════════════════════

    TracedCallback<uint8_t>  m_stateChangeTrace;   ///< Fires on state transition (0=G, 1=B)
    TracedCallback<double>   m_pdrTrace;            ///< Fires with computed PDR per transmission
    TracedCallback<bool>     m_fragmentDeliveryTrace; ///< Fires per fragment delivery attempt

  private:
    double   m_carrierFreqHz{140e9};      ///< Carrier frequency (Hz)
    double   m_velocityMs{120.0};         ///< UE velocity (m/s)
    double   m_epsilonG{1e-4};            ///< Good-state error rate
    double   m_epsilonB{0.3};             ///< Bad-state error rate
    double   m_pGB{0.05};                 ///< Transition probability G -> B
    double   m_pBG{0.3};                  ///< Transition probability B -> G
    State    m_currentState{State::GOOD}; ///< Current channel state

    Ptr<UniformRandomVariable> m_rng;     ///< RNG for state transitions and erasures

    static constexpr double SPEED_OF_LIGHT = 299792458.0; // m/s
};

} // namespace pqc
} // namespace ns3

#endif // THZ_GILBERT_ELLIOTT_CHANNEL_H
