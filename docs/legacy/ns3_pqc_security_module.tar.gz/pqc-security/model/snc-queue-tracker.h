/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
// Copyright (c) 2026 Kyber-6G Project
// SPDX-License-Identifier: GPL-2.0-only

#ifndef SNC_QUEUE_TRACKER_H
#define SNC_QUEUE_TRACKER_H

#include "ns3/object.h"
#include "ns3/nstime.h"
#include <vector>

namespace ns3 {
namespace pqc {

/**
 * \brief Stochastic Network Calculus (SNC) Queue Tracker.
 * 
 * Computes probabilistic latency-violation bounds $P(Delay > D_{max}) < \epsilon$
 * using Moment Generating Function (MGF) network calculus approaches,
 * effectively replacing deterministic M/G/1 bounds.
 */
class SncQueueTracker : public Object
{
public:
    static TypeId GetTypeId(void);
    SncQueueTracker();
    virtual ~SncQueueTracker();

    /**
     * \brief Record an arrival event.
     */
    void RecordArrival(Time arrivalTime);

    /**
     * \brief Record a service completion time.
     */
    void RecordServiceTime(Time serviceTime);

    /**
     * \brief Compute the probabilistic latency bound for a given violation probability epsilon.
     * \param epsilon The target violation probability (e.g. 1e-5).
     * \return The deterministic delay bound D_max such that P(Delay > D_max) <= epsilon.
     */
    Time ComputeProbabilisticDelayBound(double epsilon) const;

private:
    std::vector<Time> m_arrivalTimes;
    std::vector<Time> m_serviceTimes;

    // SNC internal state
    double m_theta{1.0}; // Optimization parameter for Chernoff bound
};

} // namespace pqc
} // namespace ns3

#endif /* SNC_QUEUE_TRACKER_H */
